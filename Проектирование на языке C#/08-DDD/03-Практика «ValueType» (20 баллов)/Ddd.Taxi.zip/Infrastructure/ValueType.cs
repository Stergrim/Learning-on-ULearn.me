﻿namespace Ddd.Taxi.Infrastructure;

/// <summary>
/// Базовый класс для всех Value типов.
/// </summary>
public class ValueType<T>
{
}
