﻿using NUnitLite;

namespace SRP.ControlDigit;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}