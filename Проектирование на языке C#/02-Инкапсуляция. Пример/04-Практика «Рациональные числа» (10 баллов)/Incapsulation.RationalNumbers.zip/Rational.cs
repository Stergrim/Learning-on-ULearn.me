﻿namespace Incapsulation.RationalNumbers;
