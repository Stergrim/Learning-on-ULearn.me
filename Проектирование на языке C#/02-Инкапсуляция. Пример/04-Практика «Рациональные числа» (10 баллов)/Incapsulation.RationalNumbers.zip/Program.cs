using NUnitLite;

namespace Incapsulation.RationalNumbers;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}