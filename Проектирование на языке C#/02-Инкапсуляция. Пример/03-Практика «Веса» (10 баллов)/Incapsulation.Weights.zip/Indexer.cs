﻿namespace Incapsulation.Weights;
