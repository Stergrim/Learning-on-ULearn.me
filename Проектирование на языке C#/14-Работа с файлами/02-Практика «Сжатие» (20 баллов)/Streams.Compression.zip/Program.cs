using NUnitLite;

namespace Streams.Compression;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}