﻿namespace Streams.Resources;

public class Constants
{
	public const int BufferSize = 1024;
}