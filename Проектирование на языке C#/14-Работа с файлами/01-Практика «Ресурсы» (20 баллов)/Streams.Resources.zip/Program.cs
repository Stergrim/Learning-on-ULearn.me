using NUnitLite;

namespace Streams.Resources;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}