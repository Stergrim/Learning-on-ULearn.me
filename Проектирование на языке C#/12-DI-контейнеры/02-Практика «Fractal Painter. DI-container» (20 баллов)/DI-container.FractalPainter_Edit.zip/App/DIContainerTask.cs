using System;
using System.Linq;
using Avalonia;
using Avalonia.Media;
using Avalonia.Controls;
using FractalPainting.UI;
using FractalPainting.App.Fractals;
using FractalPainting.Infrastructure.Common;
using FractalPainting.Infrastructure.UiActions;
using Ninject;
using Ninject.Extensions.Factory;
using Ninject.Extensions.Conventions;

namespace FractalPainting.App;

public static class DIContainerTask
{
	public static MainWindow CreateMainWindow() => ConfigureContainer().Get<MainWindow>();

	public static StandardKernel ConfigureContainer()
	{
		var container = new StandardKernel();
		container.Bind(x => x.FromThisAssembly().SelectAllClasses().InheritedFrom<IUiAction>().BindAllInterfaces());

		container.Bind<Palette>().To<Palette>().InSingletonScope();

		container.Bind<MainWindow>().ToSelf().InSingletonScope();
		container.Bind<Func<Window>>().ToMethod(context => () => context.Kernel.Get<MainWindow>().ShowAndReturn());

		container.Bind<AppSettings>().ToMethod(context =>
				  context.Kernel.Get<SettingsManager>().Load()).InSingletonScope();
		container.Bind<ImageSettings>().ToMethod(context =>
				  context.Kernel.Get<AppSettings>().ImageSettings).InSingletonScope();

		container.Bind<IImageController, AvaloniaImageController>().To<AvaloniaImageController>().InSingletonScope();
		container.Bind<IObjectSerializer>().To<XmlObjectSerializer>().WhenInjectedInto<SettingsManager>();
		container.Bind<IBlobStorage>().To<FileBlobStorage>().WhenInjectedInto<SettingsManager>();

		container.Bind<IDragonPainterFactory>().ToFactory();

		return container;
	}
}

public class KochFractalAction : IUiAction
{
	private readonly Lazy<KochPainter> kochPainter;
	public MenuCategory Category => MenuCategory.Fractals;
	public string Name => "Кривая Коха";
	public event EventHandler? CanExecuteChanged;

	public KochFractalAction(Lazy<KochPainter> kochPainter)
		=> this.kochPainter = kochPainter;

	public bool CanExecute(object? parameter) => true;
	public void Execute(object? parameter) => kochPainter.Value.Paint();
}

public class DragonFractalAction : IUiAction
{
	private readonly Func<Window> GetMainWindow;
	private readonly Func<DragonSettings, DragonPainter> dragonPainterFactory;
	public MenuCategory Category => MenuCategory.Fractals;
	public string Name => "Дракон";
	public event EventHandler? CanExecuteChanged;

	public DragonFractalAction(Func<Window> GetMainWindow, Func<DragonSettings, DragonPainter> dragonPainterFactory)
	{
		this.GetMainWindow = GetMainWindow;
		this.dragonPainterFactory = dragonPainterFactory;
	}

	public bool CanExecute(object? parameter) => true;

	public async void Execute(object? parameter)
	{
		var dragonSettings = CreateRandomSettings();
		await new SettingsForm(dragonSettings).ShowDialog(GetMainWindow());
		var painter = dragonPainterFactory(dragonSettings);
		painter.Paint();
	}

	private static DragonSettings CreateRandomSettings()
		=> new DragonSettingsGenerator(new Random()).Generate();
}

public interface IDragonPainterFactory
{
	public DragonPainter CreateDragonPainter(DragonSettings dragonSettings);
}

public class DragonPainter
{
	private readonly Palette palette;
	private readonly DragonSettings settings;
	private readonly IImageController imageController;

	public DragonPainter(IImageController imageController, Palette palette, DragonSettings settings)
	{
		this.palette = palette;
		this.settings = settings;
		this.imageController = imageController;
	}

	public void Paint()
	{
		using var ctx = imageController.CreateDrawingContext();
		var imageSize = imageController.GetImageSize();
		var size = Math.Min(imageSize.Width, imageSize.Height) / 2.1f;
		var backgroundBrush = new SolidColorBrush(palette.BackgroundColor);
		var primaryBrush = new SolidColorBrush(palette.PrimaryColor);
		ctx.FillRectangle(backgroundBrush, new Rect(0, 0, imageSize.Width, imageSize.Height));

		var r = new Random();
		var cosa = (float)Math.Cos(settings.Angle1); var sina = (float)Math.Sin(settings.Angle1);
		var cosb = (float)Math.Cos(settings.Angle2); var sinb = (float)Math.Sin(settings.Angle2);
		var shiftX = settings.ShiftX * size * 0.8f; var shiftY = settings.ShiftY * size * 0.8f;
		var scale = settings.Scale;
		var p = new Point(0, 0);
		foreach (var i in Enumerable.Range(0, settings.IterationsCount))
		{
			ctx.FillRectangle(primaryBrush,
				new Rect(imageSize.Width / 3f + p.X, imageSize.Height / 2f + p.Y, 1, 1));
			if (r.Next(0, 2) == 0) p = new Point(scale * (p.X * cosa - p.Y * sina),
				scale * (p.X * sina + p.Y * cosa));
			else p = new Point(scale * (p.X * cosb - p.Y * sinb) + (float)shiftX,
				scale * (p.X * sinb + p.Y * cosb) + (float)shiftY);
		}
		imageController.UpdateUi();
	}
}

public static class WindowExtensions
{
	public static Window ShowAndReturn(this Window window)
	{
		window.Show();
		return window;
	}
}