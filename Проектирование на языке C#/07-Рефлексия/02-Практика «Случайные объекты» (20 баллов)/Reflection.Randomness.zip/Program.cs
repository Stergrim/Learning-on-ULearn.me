using NUnitLite;

namespace Reflection.Randomness;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}