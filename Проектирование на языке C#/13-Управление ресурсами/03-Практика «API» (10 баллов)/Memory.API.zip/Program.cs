using NUnitLite;

namespace Memory.API;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}