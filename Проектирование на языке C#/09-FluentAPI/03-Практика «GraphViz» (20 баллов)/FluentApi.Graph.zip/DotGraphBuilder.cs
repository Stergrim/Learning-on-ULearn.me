﻿namespace FluentApi.Graph;

/*
public class DotGraphBuilder
{
	public static ... DirectedGraph(string graphName)
	{
		return ...
	}

}
*/