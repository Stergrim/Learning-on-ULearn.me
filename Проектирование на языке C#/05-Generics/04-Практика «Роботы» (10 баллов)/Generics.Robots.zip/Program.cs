using NUnitLite;

namespace Generics.Robots;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}