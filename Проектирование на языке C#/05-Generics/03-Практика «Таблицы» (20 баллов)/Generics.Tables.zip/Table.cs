﻿namespace Generics.Tables;
