﻿namespace Inheritance.DataStructure;
