using NUnitLite;

namespace Inheritance.MapObjects;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}