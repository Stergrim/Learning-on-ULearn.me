namespace Inheritance.MapObjects;

public class Treasure
{
	public int Amount { get; set; }
}