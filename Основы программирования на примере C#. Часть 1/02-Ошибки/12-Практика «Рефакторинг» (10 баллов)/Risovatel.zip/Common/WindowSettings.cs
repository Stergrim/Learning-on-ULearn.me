﻿namespace RefactorMe.Common;

public static class WindowSettings
{
	public const int Width = 800;
	public const int Height = 600;
}