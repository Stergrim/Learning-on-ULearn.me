using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace TableParser
{
    [TestFixture]
    public class QuotedFieldTaskTests
    {
        [TestCase("''", 0, "", 2)]
        [TestCase("'a'", 0, "a", 3)]
        [TestCase("\"abc\"", 0, "abc", 5)]
        [TestCase("b \"a'\"", 2, "a'", 4)]
        [TestCase(@"'a\' b'", 0, "a' b", 7)]
        public void Test(string line, int startIndex, string expectedValue, int expectedLength)
        {
            var actualToken = QuotedFieldTask.ReadQuotedField(line, startIndex);
            Assert.AreEqual(new Token(expectedValue, startIndex, expectedLength), actualToken);
        }
    }

    class QuotedFieldTask
    {
        public static Token ReadQuotedField(string line, int startIndex)
        {
            StringBuilder str = new StringBuilder();
            int len = line.Length;
            int i = startIndex;
            if ((line[i] == '\'') || (line[i] == '\"')) i++;
            for (; i < len; i++)
            {
                if ((line[i] == '\'') && (line[startIndex] != '\"')) { len = i + 1; break; }
                if (line[i] == '\\') i++;
                str.Append(line[i]);
            }
            if ((line[startIndex] == '\"') && (line[len - 1] == '\"')) str.Remove(str.Length - 1, 1);
            line = str.ToString();
            return new Token(line, startIndex, len - startIndex);
        }
    }
}