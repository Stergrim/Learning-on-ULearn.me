﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Autocomplete
{
	public class LeftBorderTask
	{
		public static int GetLeftBorderIndex(IReadOnlyList<string> phrases, string prefix,
											 int left, int right)
		{
			if (left + 1 >= right) return left;
			int m = (right - left) / 2 + left;

			if (string.Compare(prefix, phrases[m],
							   StringComparison.InvariantCultureIgnoreCase) < 0 ||
				phrases[m].StartsWith(prefix, StringComparison.InvariantCultureIgnoreCase))
				return GetLeftBorderIndex(phrases, prefix, left, m);
			else return GetLeftBorderIndex(phrases, prefix, m, right);
		}
	}
}