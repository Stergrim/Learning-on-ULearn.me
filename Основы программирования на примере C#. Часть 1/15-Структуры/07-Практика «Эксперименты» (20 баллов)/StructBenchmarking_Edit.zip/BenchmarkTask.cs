using System;
using System.Collections.Generic;
using System.Diagnostics;
using NUnit.Framework;

namespace StructBenchmarking
{
    public class Benchmark : IBenchmark
    {
        public double MeasureDurationInMs(ITask task, int repetitionCount)
        {
            task.Run();
            double timeAll = 0.0;
            for (var i = 0; i < repetitionCount; i++)
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                var time = Stopwatch.StartNew();
                task.Run();
                time.Stop();
                timeAll += time.ElapsedMilliseconds;
            }
            return (double)timeAll / repetitionCount;
        }
    }

    public class BuilderTest : ITask
    {
        public System.Text.StringBuilder Str = new System.Text.StringBuilder { };
        public void Run()
        {
            for (var i = 0; i < 10000; i++)
                Str.Append('a');
            Str.ToString();
        }
    }

    public class StringTest : ITask
    {
        public string Str;
        public void Run() { Str = new string('a', 10000); }
    }

    [TestFixture]
    public class RealBenchmarkUsageSample
    {
        [Test]
        public void StringConstructorFasterThanStringBuilder()
        {
            var builderTest = new BuilderTest();
            var stringTest = new StringTest();
            var benchmark = new Benchmark();

            var firstTest = benchmark.MeasureDurationInMs(builderTest, 100);
            var secondTest = benchmark.MeasureDurationInMs(stringTest, 100);
            Assert.Less(secondTest, firstTest);
        }
    }
}