﻿using System.Collections.Generic;

namespace TextAnalysis
{
    static class TextGeneratorTask
    {
        public static string ContinuePhrase(Dictionary<string, string> nextWords,
                                            string phraseBeginning, int wordsCount)
        {
            List<string> str = new List<string>();
            string[] temp = phraseBeginning.Split(' ');
            for (int j = 0; j < temp.Length; j++)
                str.Add(temp[j]);
            for (int i = 0; i < wordsCount; i++)
            {
                if (str.Count < 2)
                    if (nextWords.ContainsKey(str[0])) str.Add(nextWords[str[0]]);
                    else break;
                else if (nextWords.ContainsKey(str[str.Count - 2] + " " + str[str.Count - 1]))
                    str.Add(nextWords[str[str.Count - 2] + " " + str[str.Count - 1]]);
                else if (nextWords.ContainsKey(str[str.Count - 1]))
                    str.Add(nextWords[str[str.Count - 1]]);
                else break;
            }
            phraseBeginning = string.Join(" ", str.ToArray());
            return phraseBeginning;
        }
    }
}