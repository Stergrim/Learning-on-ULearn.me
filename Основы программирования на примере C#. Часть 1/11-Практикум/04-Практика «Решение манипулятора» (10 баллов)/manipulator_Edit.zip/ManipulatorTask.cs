using System;
using NUnit.Framework;
using static Manipulation.Manipulator;

namespace Manipulation
{
    public static class ManipulatorTask
    {
        public static double[] MoveManipulatorTo(double x, double y, double alpha)
        {
            double xPalm = x - Palm * (double)Math.Cos(alpha);
            double yPalm = y + Palm * (double)Math.Sin(alpha);
            double c = Math.Sqrt(xPalm * xPalm + yPalm * yPalm);
            double elbow = TriangleTask.GetABAngle(UpperArm, Forearm, c);
            double shoulderPath1 = TriangleTask.GetABAngle(UpperArm, c, Forearm);
            double shoulderPath2 = Math.Atan2(yPalm, xPalm);
            double shoulder = shoulderPath1 + shoulderPath2;
            double wrist = -alpha - shoulder - elbow;
            if (shoulder == double.NaN || elbow == double.NaN)
                return new[] { double.NaN, double.NaN, double.NaN };
            return new[] { shoulder, elbow, wrist };
        }
    }

    [TestFixture]
    public class ManipulatorTask_Tests
    {
        [Test]
        public void TestMoveManipulatorTo()
        {
            var trialsCount = 100;
            var angles = ManipulatorTask.MoveManipulatorTo(0, 0, 0);
            var positions = AnglesToCoordinatesTask.GetJointPositions(0, 0, 0);
            Random rnd = new Random();
            for (int i = 0; i < trialsCount; i++)
            {
                var x = rnd.Next(-1000, 1000);
                var y = rnd.Next(-1000, 1000);
                var alpha = rnd.NextDouble() * Math.PI * 2;

                angles = ManipulatorTask.MoveManipulatorTo(x, y, alpha);
                positions = AnglesToCoordinatesTask.GetJointPositions(angles[0],
                                                                      angles[1], angles[2]);
                if (angles[0].Equals(double.NaN))
                {
                    Assert.AreEqual(double.NaN, positions[2].X);
                    Assert.AreEqual(double.NaN, positions[2].Y);
                }
                else
                {
                    Assert.AreEqual(x, positions[2].X, 1e-3);
                    Assert.AreEqual(y, positions[2].Y, 1e-3);
                }
            }
        }
    }
}