﻿using System.Collections.Generic;
using Avalonia.Media;
using GeometryTasks;

namespace GeometryPainting;

//Напишите здесь код, который заставит работать методы segment.GetColor и segment.SetColor