﻿using System.Collections.Generic;
using Avalonia.Media;
using GeometryTasks;

namespace GeometryPainting
{
    public static class SegmentExtensions
    {
        public static Dictionary<Segment, Color> SegmentColor =
                      new Dictionary<Segment, Color>();

        public static void SetColor(this Segment segment, Color color)
        {
            if (SegmentColor.ContainsKey(segment)) SegmentColor[segment] = color;
            else SegmentColor.Add(segment, color);
        }

        public static Color GetColor(this Segment segment)
        {
            if (!SegmentColor.ContainsKey(segment)) SegmentColor.Add(segment, new Color());
            if (SegmentColor[segment].Equals(null)) return Colors.Black;
            else return SegmentColor[segment];
        }
    }
}