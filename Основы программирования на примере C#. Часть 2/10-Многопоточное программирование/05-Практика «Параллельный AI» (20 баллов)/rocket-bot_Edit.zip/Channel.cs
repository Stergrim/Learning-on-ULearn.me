using System.Linq;
using System.Collections.Generic;

namespace rocket_bot;

public class Channel<T> where T : class
{
	private T? lastItem;
	private readonly List<T> items = new List<T>();

	public T this[int index]
	{
		get
		{
			lock (this)
			{
				if (index < this.Count) return items.ElementAt(index);
				return null;
			}
		}
		set
		{
			lock (this)
			{
				if (index < Count)
				{
					lastItem = value;
					items[index] = value;
					items.RemoveRange(index + 1, items.Count - index - 1);
				}
				else if (index == Count)
				{
					lastItem = value;
					items.Add(value);
				}
			}
		}
	}

	public T LastItem()
	{
		return lastItem;
	}

	public void AppendIfLastItemIsUnchanged(T item, T knownLastItem)
	{
		if (this.LastItem() == knownLastItem) this[Count] = item;
	}

	public int Count
	{
		get
		{
			return items.Count;
		}
	}
}