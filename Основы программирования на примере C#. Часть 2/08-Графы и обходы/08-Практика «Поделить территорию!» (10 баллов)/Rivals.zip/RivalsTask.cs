﻿using System.Collections.Generic;

namespace Rivals;

public class RivalsTask
{
	public static IEnumerable<OwnedLocation> AssignOwners(Map map)
	{
		yield break;
	}
}