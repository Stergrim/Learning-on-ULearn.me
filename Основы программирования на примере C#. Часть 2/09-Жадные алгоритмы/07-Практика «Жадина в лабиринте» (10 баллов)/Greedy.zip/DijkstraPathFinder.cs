using System;
using System.Collections.Generic;
using Greedy.Architecture;

namespace Greedy;

public class DijkstraPathFinder
{
	public IEnumerable<PathWithCost> GetPathsByDijkstra(State state, Point start,
		IEnumerable<Point> targets)
	{
		throw new NotImplementedException();
	}
}