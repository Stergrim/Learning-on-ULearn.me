﻿using System.Collections.Generic;
using Greedy.Architecture;
using System.Linq;

namespace Greedy;

public class GreedyPathFinder : IPathFinder
{
	public List<Point> FindPathToCompleteGoal(State state)
	{
		var pathFinder = new DijkstraPathFinder();
		var paths = pathFinder.GetPathsByDijkstra(state, state.Position, state.Chests);
		if (state.Goal > state.Chests.Count) return new List<Point>();

		int cost = 0;
		var totalPath = new List<Point>();
		while (paths.Any())
		{
			var path = paths.First();
			state.Scores++;
			if (state.Scores > state.Goal) break;
			totalPath.AddRange(path.Path.Skip(1).ToList());
			cost += path.Cost;
			state.Position = path.End;
			state.Chests.Remove(path.End);
			paths = pathFinder.GetPathsByDijkstra(state, state.Position, state.Chests);
		}

		if (totalPath.Count == 0) return new List<Point>();
		if (state.Energy < cost) return new List<Point>();
		return totalPath;
	}
}