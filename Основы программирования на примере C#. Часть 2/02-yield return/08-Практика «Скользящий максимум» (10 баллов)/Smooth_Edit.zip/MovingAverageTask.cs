using System.Collections;
using System.Collections.Generic;

namespace yield
{
	public static class MovingAverageTask
	{
		public static IEnumerable<DataPoint> MovingAverage(this IEnumerable<DataPoint> data,
														   int windowWidth)
		{
			var x = data.GetEnumerator();
			if (!x.MoveNext()) yield break;
			Queue myQ = new Queue();
			myQ.Enqueue(x.Current.OriginalY);
			double sum = x.Current.OriginalY;
			yield return x.Current.WithAvgSmoothedY(sum);
			while (x.MoveNext())
			{
				myQ.Enqueue(x.Current.OriginalY);
				sum += x.Current.OriginalY;
				if (myQ.Count > windowWidth) sum -= (double)myQ.Dequeue();
				yield return x.Current.WithAvgSmoothedY(sum / myQ.Count);
			}
		}
	}
}