using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace yield
{
	public static class MovingMaxTask
	{
		public static IEnumerable<DataPoint> MovingMax(this IEnumerable<DataPoint> data,
													   int windowWidth)
		{
			var x = data.GetEnumerator();
			if (!x.MoveNext()) yield break;
			Queue myQ = new Queue();
			LinkedList<double> listMax = new LinkedList<double>();
			myQ.Enqueue(x.Current.OriginalY);
			listMax.AddFirst(x.Current.OriginalY);
			yield return x.Current.WithMaxY(x.Current.OriginalY);
			while (x.MoveNext())
			{
				myQ.Enqueue(x.Current.OriginalY);
				if (x.Current.OriginalY > listMax.First.Value)
				{ listMax.Clear(); listMax.AddFirst(x.Current.OriginalY); }
				else
				{
					while (listMax.Last.Value < x.Current.OriginalY)
						listMax.RemoveLast();
					listMax.AddLast(x.Current.OriginalY);
				}

				if (myQ.Count > windowWidth)
					if (listMax.First().Equals(myQ.Dequeue())) listMax.RemoveFirst();
				yield return x.Current.WithMaxY(listMax.First());
			}
		}
	}
}