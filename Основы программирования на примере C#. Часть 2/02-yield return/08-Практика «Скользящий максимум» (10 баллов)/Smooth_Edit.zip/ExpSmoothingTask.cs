using System.Collections.Generic;

namespace yield
{
	public static class ExpSmoothingTask
	{
		public static IEnumerable<DataPoint> SmoothExponentialy(
			this IEnumerable<DataPoint> data, double alpha)
		{
			var x = data.GetEnumerator();
			if (!x.MoveNext()) yield break;
			var s = x.Current.OriginalY;
			yield return x.Current.WithExpSmoothedY(s);
			while (x.MoveNext())
			{
				s += (x.Current.OriginalY - s) * alpha;
				yield return x.Current.WithExpSmoothedY(s);
			}
		}
	}
}