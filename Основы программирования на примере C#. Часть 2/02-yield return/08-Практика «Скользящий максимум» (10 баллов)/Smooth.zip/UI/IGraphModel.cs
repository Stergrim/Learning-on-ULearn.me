namespace yield.UI;

interface IGraphModel
{
    void AddPoint(DataPoint p);
}