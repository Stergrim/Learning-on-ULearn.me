using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace func.brainfuck
{
	public class BrainfuckBasicCommands
	{
		public static void RegisterTo(IVirtualMachine vm, Func<int> read, Action<char> write)
		{
			vm.RegisterCommand('.', b => write(Convert.ToChar(vm.Memory[vm.MemoryPointer])));
			vm.RegisterCommand('+', b => {
				int a = vm.Memory[vm.MemoryPointer]; a++; if (a > 255) a = 0;
				vm.Memory[vm.MemoryPointer] = Convert.ToByte(a);
			});
			vm.RegisterCommand('-', b => {
				int a = vm.Memory[vm.MemoryPointer]; a--; if (a < 0) a = 255;
				vm.Memory[vm.MemoryPointer] = Convert.ToByte(a);
			});
			vm.RegisterCommand(',', b => vm.Memory[vm.MemoryPointer] =
							   Convert.ToByte(read().ToString()));
			vm.RegisterCommand('>', b => {
				vm.MemoryPointer++;
				if (vm.MemoryPointer >= vm.Memory.Length) vm.MemoryPointer = 0;
			});
			vm.RegisterCommand('<', b => {
				vm.MemoryPointer--;
				if (vm.MemoryPointer < 0) vm.MemoryPointer = vm.Memory.Length - 1;
			});
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			foreach (var c in chars)
				vm.RegisterCommand(c, b => vm.Memory[vm.MemoryPointer] = Convert.ToByte(c));
		}
	}
}