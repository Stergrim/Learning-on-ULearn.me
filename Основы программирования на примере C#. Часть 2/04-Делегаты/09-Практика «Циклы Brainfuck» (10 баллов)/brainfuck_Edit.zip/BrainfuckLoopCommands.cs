using System.Collections.Generic;

namespace func.brainfuck
{
	public class BrainfuckLoopCommands
	{
		public static Dictionary<int, int> StartAndEnd { get; set; }
		public static Stack<int> StackLoop { get; set; }

		public static void RegisterTo(IVirtualMachine vm)
		{
			StartAndEnd = new Dictionary<int, int> { };
			StackLoop = new Stack<int> { };
			for (int i = 0; i < vm.Instructions.Length; i++)
				switch (vm.Instructions[i])
				{
					case '[': { StackLoop.Push(i); break; }
					case ']':
						var start = StackLoop.Pop();
						StartAndEnd.Add(i, start);
						StartAndEnd.Add(start, i);
						break;
				}
			vm.RegisterCommand('[', b => {
				if (vm.Memory[vm.MemoryPointer] > 0) StackLoop.Push(vm.InstructionPointer);
				else vm.InstructionPointer = StartAndEnd[vm.InstructionPointer];
			});
			vm.RegisterCommand(']', b => {
				if (vm.Memory[vm.MemoryPointer] > 0) vm.InstructionPointer =
													 StartAndEnd[vm.InstructionPointer];
				else StackLoop.Pop();
			});
		}
	}
}