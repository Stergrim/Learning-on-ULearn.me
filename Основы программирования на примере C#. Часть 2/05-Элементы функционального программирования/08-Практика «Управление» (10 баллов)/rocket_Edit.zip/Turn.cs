﻿namespace func_rocket;

public enum Turn
{
	None = 0,
	Left = -1,
	Right = 1
}