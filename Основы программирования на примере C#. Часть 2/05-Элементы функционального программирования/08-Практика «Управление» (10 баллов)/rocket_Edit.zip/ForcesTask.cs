﻿using System;

namespace func_rocket
{
	public class ForcesTask
	{
		public static RocketForce GetThrustForce(double forceValue)
		{
			return r => new Vector(forceValue * Math.Cos(r.Direction),
								   forceValue * Math.Sin(r.Direction));
		}

		public static RocketForce ConvertGravityToForce(Gravity gravity, Vector spaceSize)
		{ return r => gravity(spaceSize, r.Location); }

		public static RocketForce Sum(params RocketForce[] forces)
		{
			return r =>
			{
				double X = 0; double Y = 0;
				foreach (var force in forces)
				{ X += force(r).X; Y += force(r).Y; }
				return new Vector(X, Y);
			};
		}
	}
}