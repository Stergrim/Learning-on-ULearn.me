namespace func_rocket;

public delegate Vector RocketForce(Rocket rocket);