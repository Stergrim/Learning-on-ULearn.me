﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace linq_slideviews
{
	public class StatisticsTask
	{
		public static double GetMedianTimePerSlide(List<VisitRecord> visits,
												   SlideType slideType)
		{
			return visits
				   .OrderBy(x => x.DateTime)
				   .GroupBy(x => x.UserId)
				   .Select(x => x.Bigrams()
								.Where(user => user.First.UserId.Equals(user.Second.UserId)))
				   .SelectMany(x => x)
				   .Where(x => x.First.SlideType == slideType)
				   .Select(x => x.Second.DateTime.Subtract(x.First.DateTime).TotalMinutes)
				   .Where(x => !((x < 1.0) || (x > 120)))
				   .DefaultIfEmpty()
				   .Median();
		}
	}
}