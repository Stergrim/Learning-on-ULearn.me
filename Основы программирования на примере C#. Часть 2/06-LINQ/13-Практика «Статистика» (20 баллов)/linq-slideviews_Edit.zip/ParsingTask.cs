﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace linq_slideviews
{
	public class ParsingTask
	{
		public static IDictionary<int, SlideRecord> ParseSlideRecords(IEnumerable<string> lines)
		{
			var dictionary = new Dictionary<int, SlideRecord>();
			string[] parseLine;
			int id = 0;
			SlideType type;
			foreach (var line in lines.Skip(1))
			{
				parseLine = line.Split(';', StringSplitOptions.None);
				if ((parseLine.GetLength(0) == 3) &&
					int.TryParse(parseLine[0], out id) &&
					SlideType.TryParse(parseLine[1], true, out type))
					dictionary.Add(id, new SlideRecord(id, type, parseLine[2]));
			}
			return dictionary;
		}

		public static IEnumerable<VisitRecord> ParseVisitRecords(
					  IEnumerable<string> lines, IDictionary<int, SlideRecord> slides)
		{
			string[] parseLine;
			int userId;
			int slideId;
			DateTime dateTime;
			foreach (var line in lines.Skip(1))
			{
				parseLine = line.Split(';', StringSplitOptions.None);

				if ((parseLine.GetLength(0) == 4) &&
					int.TryParse(parseLine[0], out userId) &&
					int.TryParse(parseLine[1], out slideId) &&
					DateTime.TryParse(parseLine[2] + " " + parseLine[3], out dateTime) &&
					slides.ContainsKey(slideId))
					yield return new VisitRecord(userId,
												 slideId,
												 dateTime,
												 slides[slideId].SlideType);
				else throw new FormatException("Wrong line [" + line + "]");
			}
		}
	}
}