﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace linq_slideviews
{
	public static class ExtensionsTask
	{
		public static double Median(this IEnumerable<double> items)
		{
			int count;
			var sources = items.OrderBy(x => x);
			sources.TryGetNonEnumeratedCount(out count);
			double mediana = 0;
			int i = 0;
			foreach (var source in sources)
			{
				i++;
				if (i == count / 2 + 1)
					if (count % 2 == 0) return (mediana + source) / 2;
					else return source;
				mediana = source;
			}
			throw new InvalidOperationException();
		}

		public static IEnumerable<(T First, T Second)> Bigrams<T>(this IEnumerable<T> items)
		{
			var q = new Queue<T>();
			foreach (var source in items)
			{
				q.Enqueue(source);
				if (q.Count > 1) yield return new(q.Dequeue(), q.Peek());
			}
		}
	}
}