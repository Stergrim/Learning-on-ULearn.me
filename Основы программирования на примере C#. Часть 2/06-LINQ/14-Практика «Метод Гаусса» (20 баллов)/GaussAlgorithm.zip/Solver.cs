using System;
using System.Linq;

namespace GaussAlgorithm;

public class Solver
{
	public double[] Solve(double[][] matrix, double[] freeMembers)
	{
		throw new NotImplementedException();
	}
}