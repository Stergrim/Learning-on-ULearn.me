﻿using System;

namespace LimitedSizeStack;

public class LimitedSizeStack<T>
{
	public LimitedSizeStack(int undoLimit)
	{
	}

	public void Push(T item)
	{
		throw new NotImplementedException();
	}

	public T Pop()
	{
		throw new NotImplementedException();
	}

	public int Count => throw new NotImplementedException();
}