﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LimitedSizeStack
{
    public class StackItem<T>
    {
        public T Value { get; set; }
        public StackItem<T> Previous { get; set; }
        public StackItem<T> Next { get; set; }
    }

    public class LimitedSizeStack<T>
    {
        int limit;
        int count;
        StackItem<T> head;
        StackItem<T> tail;

        public LimitedSizeStack(int limit)
        {
            if (limit < 0) throw new NotImplementedException();
            this.limit = limit;
        }

        public void Push(T value)
        {
            count++;
            if (head == null)
                tail = head = new StackItem<T> { Value = value, Previous = null, Next = null };
            else
            {
                var item = new StackItem<T> { Value = value, Previous = tail, Next = null };
                tail.Next = item;
                tail = item;
            }
            if (limit == 0) count--;
            else if (count > limit)
            {
                count--;
                head = head.Next;
                head.Previous = null;
            }
        }

        public T Pop()
        {
            if (tail == null) throw new InvalidOperationException();
            var result = tail.Value;
            tail = tail.Previous;
            count--;
            if (tail == null)
                head = null;
            return result;
        }

        public int Count { get => this.count; }
    }
}