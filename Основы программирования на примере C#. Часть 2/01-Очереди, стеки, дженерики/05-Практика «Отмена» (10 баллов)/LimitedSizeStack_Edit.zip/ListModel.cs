﻿using System;
using System.Collections.Generic;

namespace LimitedSizeStack
{
    public class ListModel<TItem>
    {
        LimitedSizeStack<Tuple<string, TItem, int>> Stack;
        public List<TItem> Items { get; }
        public int Limit;

        public ListModel(int limit)
        {
            Items = new List<TItem>();
            Limit = limit;
            Stack = new LimitedSizeStack<Tuple<string, TItem, int>>(limit);
        }

        public void AddItem(TItem item)
        { Stack.Push(Tuple.Create("Добавить", item, Items.Count)); Items.Add(item); }

        public void RemoveItem(int index)
        { Stack.Push(Tuple.Create("Удалить", Items[index], index)); Items.RemoveAt(index); }

        public bool CanUndo() { return !(Stack.Count == 0); }

        public void Undo()
        {
            var operration = Stack.Pop();
            if (operration.Item1 == "Добавить") { Items.RemoveAt(operration.Item3); }
            else if (operration.Item1 == "Удалить")
            { Items.Insert(operration.Item3, operration.Item2); }
        }
    }
}