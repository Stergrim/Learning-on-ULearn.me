using System;
using System.Collections.Generic;
using DocumentTokens = System.Collections.Generic.List<string>;

namespace Antiplagiarism;

public class LevenshteinCalculator
{
	public List<ComparisonResult> CompareDocumentsPairwise(List<DocumentTokens> documents)
	{
		var listComparison = new List<ComparisonResult>();

		int i = 0;
		int j = i + 1;
		while (i < documents.Count - 1)
		{
			j = i + 1;
			while (j < documents.Count)
			{
				listComparison.Add(GetLevenshteinDistance(documents[i], documents[j]));
				j++;
			}
			i++;
		}

		return listComparison;
	}

	private ComparisonResult GetLevenshteinDistance(DocumentTokens firstDocument, DocumentTokens secondDocument)
	{
		var opt = new double[firstDocument.Count + 1, secondDocument.Count + 1];
		for (var k = 0; k <= firstDocument.Count; ++k) { opt[k, 0] = k; }
		for (var m = 0; m <= secondDocument.Count; ++m) { opt[0, m] = m; }

		for (var k = 1; k <= firstDocument.Count; ++k)
			for (var m = 1; m <= secondDocument.Count; ++m)
			{
				if (firstDocument[k - 1] == secondDocument[m - 1])
					opt[k, m] = opt[k - 1, m - 1];
				else
				{
					double delete = opt[k - 1, m] + 1;
					double additional = opt[k, m - 1] + 1;
					double replace = opt[k - 1, m - 1] +
						TokenDistanceCalculator.GetTokenDistance(firstDocument[k - 1], secondDocument[m - 1]);

					opt[k, m] = Math.Min(Math.Min(delete, additional), replace);
				}
			}

		return new ComparisonResult(firstDocument, secondDocument, opt[firstDocument.Count, secondDocument.Count]);
	}
}