﻿using NUnitLite;

namespace Tickets;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}