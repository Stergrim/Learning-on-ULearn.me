from django.db import models


class SiteUser(models.Model):
    # TODO: реализовать модель для взаимодействия с таблицей site_users
    pass


class Vacancy(models.Model):
    # TODO: реализовать модель для взаимодействия с таблицей vacancies
    pass