from django.db import models
import hashlib


class MyUser(models.Model):
    raise NotImplementedError


class Vacancy(models.Model):
    raise NotImplementedError


class Skill(models.Model):
    raise NotImplementedError


class VacancySkill(models.Model):
    raise NotImplementedError


class UserSkill(models.Model):
    raise NotImplementedError


class UserResponse(models.Model):
    raise NotImplementedError
