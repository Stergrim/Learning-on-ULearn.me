module ValueOrErrorMonadSpec where

import Test.Hspec
import Test.QuickCheck

import RegistrationRequest
import ValueOrErrorMonad
import ValueOrError

main = hspec spec

createError :: ErrorCode -> String -> ValueOrError a
createError code message = Error code message

requestFromName :: String -> RegistrationRequest
requestFromName name = RegistrationRequest name "surname" 34 "motto"

requestFromSurname :: String -> RegistrationRequest
requestFromSurname surname = RegistrationRequest "name" surname 34 "motto"

spec :: Spec
spec = do
  describe "normalize" $ do
    it "validate name on \"\"" $
      normalize (requestFromName "") `shouldBe` createError InvalidArgument "String value cannot be empty"
    it "validate name length" $
      normalize (requestFromName (replicate 65 'a')) `shouldBe` createError InvalidArgument "String value cannot be longer than 64 chars"
    it "validate surname on \"\"" $
      normalize (requestFromSurname "") `shouldBe` createError InvalidArgument "String value cannot be empty"
    it "validate surname length" $
      normalize (requestFromSurname (replicate 65 'a')) `shouldBe` createError InvalidArgument "String value cannot be longer than 64 chars"
    it "validate age >= 18" $
      normalize (RegistrationRequest "name" "surname" 17 "motto") `shouldBe` createError AccessDenied "Only 18+ are allowed"
    it "validate moto" $
      normalize (RegistrationRequest "name" "surname" 18 "faithful though unfortunate") `shouldBe` createError GenericError "You copied motto from somewhere, didn't you?"
    it "normalize name" $
      normalize (requestFromName "NaMe") `shouldBe` Result (requestFromName "name")
    it "normalize surname" $
      normalize (requestFromSurname "sUrNaMe") `shouldBe` Result (requestFromSurname "surname")
    it "first normalize motto, then validate" $
      normalize (RegistrationRequest "name" "surname" 18 "Faithful Though Unfortunate") `shouldBe` createError GenericError "You copied motto from somewhere, didn't you?"