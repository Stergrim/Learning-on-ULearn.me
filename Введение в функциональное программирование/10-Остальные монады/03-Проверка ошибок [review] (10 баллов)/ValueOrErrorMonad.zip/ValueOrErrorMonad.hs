module ValueOrErrorMonad where

import ValueOrError
import RegistrationRequest

normalize :: RegistrationRequest -> ValueOrError RegistrationRequest
normalize (RegistrationRequest name surname age motto) =
  case normalizeStringField name of
    (Error code message) -> Error code message
    (Result normalizedName) -> case normalizeStringField surname of
      (Error code message) -> Error code message
      (Result normalizedSurname) -> case normalizeStringField motto of
        (Error code message) -> Error code message
        (Result normalizedMotto) -> case validateAge age of
          (Error code message) -> Error code message
          (Result _) -> case checkUniqueMotto normalizedMotto of
            (Error code message) -> Error code message
            (Result _) -> Result $ RegistrationRequest normalizedName normalizedSurname age normalizedMotto