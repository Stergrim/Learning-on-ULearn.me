module RegistrationRequest where

import ValueOrError
import Data.Char (toLower)

data RegistrationRequest = RegistrationRequest
  { name :: String
  , surname :: String
  , age :: Int
  , motto :: String
  }
  deriving (Eq, Show)

normalizeStringField :: String -> ValueOrError String
normalizeStringField value
  | value == "" = Error InvalidArgument "String value cannot be empty"
  | length value > 64 = Error InvalidArgument "String value cannot be longer than 64 chars"
  | otherwise = return $ map toLower value

validateAge :: Int -> ValueOrError ()
validateAge age
  | age < 18 = Error AccessDenied "Only 18+ are allowed"
  | otherwise = return ()

checkUniqueMotto :: String -> ValueOrError ()
checkUniqueMotto motto
  | motto == "faithful though unfortunate" = Error GenericError "You copied motto from somewhere, didn't you?"
  | otherwise = return ()