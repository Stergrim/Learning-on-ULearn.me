module ValueOrError where

data ErrorCode
  = InvalidArgument
  | AccessDenied
  | GenericError
  deriving (Eq, Show)

data ValueOrError a = Error
  { code :: ErrorCode
  , message :: String }
  | Result a
  deriving (Eq, Show)

instance Functor ValueOrError where
  fmap f (Result a) = Result $ f a
  fmap _ (Error code message) = Error code message

instance Applicative ValueOrError where
  pure = Result

  (Result f) <*> a = f <$> a
  (Error code message) <*> _ = Error code message

instance Monad ValueOrError where
  (Result a) >>= f = f a
  (Error code message) >>= _ = Error code message