module Spam where

import Control.Monad.Reader
-- Чтобы встроенная функция id не мешала использовать getter Person
import Prelude hiding (id)

import Person
import DataBase

-- Поиск персоны по id
findById :: PersonId -> Reader [Person] (Maybe Person)
findById pId = error "not implemented"

processSingle :: Person -> String
processSingle p = error "not implemented"

processPair :: Person -> Person -> String
processPair spouse1 spouse2 = error "not implemented"

processPerson :: PersonId -> Reader [Person] (Maybe String)
processPerson pId = error "not implemented"

processPersons :: [PersonId] -> [Maybe String]
processPersons personIds = error "not implemented"