module SpamSpec where

import Test.Hspec
import Test.QuickCheck

import Spam
import Person
import DataBase

main = hspec spec

spec :: Spec
spec = do
  describe "Reader" $ do
    it "processPersons [1,2,3]" $
      processPersons [1,2,3] `shouldBe`
        [ Just $ "Уважаемый Иван Иванович!\n" ++
        "Разрешите предложить Вам наши услуги."
        , Just $ "Уважаемые Петр Петрович и Екатерина Алексеевна!\n" ++
        "Разрешите предложить вам наши услуги."
        , Just $ "Уважаемая Алия Фаридовна!\n" ++
        "Разрешите предложить Вам наши услуги."
        ]
    it "processPersons [9,7,10]" $
      processPersons [9,7,10] `shouldBe`
        [ Just $ "Уважаемый Юрий Васильевич!\n" ++
        "Разрешите предложить Вам наши услуги."
        , Just $ "Уважаемые Екатерина Алексеевна и Петр Петрович!\n" ++
        "Разрешите предложить вам наши услуги."
        , Nothing
        ]