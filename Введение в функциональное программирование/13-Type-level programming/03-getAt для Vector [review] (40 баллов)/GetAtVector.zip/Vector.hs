{-# LANGUAGE GADTs #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE KindSignatures #-}

module Vector where

import Data.Kind

data Nat = Zero | Succ Nat deriving (Eq, Show)

data Vector a (n :: Nat) where
  Nil :: Vector a 'Zero
  (:|) :: a -> Vector a n -> Vector a ('Succ n)

infixr 5 :|

instance Show a => Show (Vector a n) where
  show Nil = "nil"
  show (x :| xs) = show x ++ " : " ++ show xs

data SNat :: Nat -> Type where
  SZero :: SNat 'Zero
  SSucc :: SNat n -> SNat ('Succ n)

replicateVec :: SNat n -> a -> Vector a n
replicateVec sn x = case sn of
  SZero -> Nil
  (SSucc sn) -> x :| (replicateVec sn x)
