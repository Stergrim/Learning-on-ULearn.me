{-# LANGUAGE GADTs #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}

module GetAtVector
  -- Так при импорте GetAtVector или его загрузке в GHCi
  -- модули Vector и SNats будут импортироваться автоматически
  ( module GetAtVector
  , module Vector
  , module SNats)
  where

import Vector
import SNats

-- Мы оставили тип таким, так он и будет выглядеть для
-- внешнего пользователя функции. Но его придётся доработать.
-- Тип этого метода — часть решения задачи.
getAt :: Vector a n -> SNat m -> a
getAt = undefined
