{-# LANGUAGE TypeApplications #-}

module CountingSortSpec where

import Test.Hspec
import Test.QuickCheck

import CountingSort
import Data.Array

main = hspec spec

spec :: Spec
spec = do
  describe "countingSort @[Int]" $ do
    it "countingSort  @[Int] [] ~> []" $
      countingSort @[Int] [] `shouldBe` []
    it "countingSort @[Int] [0..10] ~> [0..10]" $
      countingSort @[Int] [0..10] `shouldBe` [0..10]
    it "countingSort @[Int] [10..1] ~> [1..10]" $
      countingSort @[Int] (reverse [1..10]) `shouldBe` [1..10]
    it "countingSort [6,5,6,0,1,6,7,2] ~> [0,1,2,5,6,6,6,7]" $
      countingSort @[Int] [6,5,6,0,1,6,7,2] `shouldBe` [0,1,2,5,6,6,6,7]

  describe "countingSort @(Array Int Int)" $ do
    it "countingSort @(Array Int Int) [] ~> []" $
      countingSort @(Array Int Int) [] `shouldBe` []
    it "countingSort @(Array Int Int) [0..10] ~> [0..10]" $
      countingSort @(Array Int Int) [0..10] `shouldBe` [0..10]
    it "countingSort @(Array Int Int) [10..1] ~> [1..10]" $
      countingSort @(Array Int Int) (reverse [1..10]) `shouldBe` [1..10]
    it "countingSort [6,5,6,0,1,6,7,2] ~> [0,1,2,5,6,6,6,7]" $
      countingSort @(Array Int Int) [6,5,6,0,1,6,7,2] `shouldBe` [0,1,2,5,6,6,6,7]