-- Расширения из прошлого задания
{-# LANGUAGE FlexibleInstances, AllowAmbiguousTypes #-}

-- С этими двумя расширениями мы познакомились в 5ой лекции про SystemF

-- Включает аппликацию типа t @T
{-# LANGUAGE TypeApplications #-}

-- Включает использование переменных типа, объявленных в типе функции
-- внутри тела этой функции (пригодится в countingSort)
{-# LANGUAGE ScopedTypeVariables #-}

module CountingSort where

{-
  Вы можете использовать ключевое слово qualified при подключении модулей,
  чтобы компилятор явно требовал указание имени модуля для всех функций из
  этого модуля. Например, если вы подключили модуль Data.IntMap так:

  import qualified Data.IntMap as Map

  то к каждой функции нужно будет обращаться с префиксом `Map.`, например Map.toList.

  Это может понадобится, если в разных модулях встречаются функции с одинаковыми
  именами.
-}

-- Сначала скопируйте сюда реализованный вами класс IntArray
-- и все его instance'ы

-- class IntArray a where
-- ...

-- instance IntArray [Int] where
-- ...

-- Использует ограничение `IntArray a`, хотя `a` не встречается в типе функции.
-- Зато это ограничение делает доступными функции класса IntArray в теле countingSort.
countingSort :: forall a. IntArray a => [Int] -> [Int]
countingSort = error "not implemented"
