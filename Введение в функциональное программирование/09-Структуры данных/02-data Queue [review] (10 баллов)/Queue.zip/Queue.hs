module Queue where

data Queue a = ...

createQueue :: Queue a
createQueue = error "not implemented"

enqueue :: Queue a -> a -> Queue a
enqueue queue x = error "not implemented"

-- Если очередь пустая, функция просто падает с ошибкой
dequeue :: Queue a -> (a, Queue a)
dequeue queue = error "not implemented"

isEmpty :: Queue a -> Bool
isEmpty queue = error "not implemented"