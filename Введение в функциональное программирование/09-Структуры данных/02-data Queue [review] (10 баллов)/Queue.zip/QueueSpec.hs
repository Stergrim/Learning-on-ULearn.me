module QueueSpec where

import Test.Hspec
import Test.QuickCheck

import Queue

main = hspec spec

one :: Int
one = 1

spec :: Spec
spec = do
    describe "Queue" $ do
    it "isEmpty emptyQueue ~> True" $
      isEmpty createQueue `shouldBe` True
    it "isEmpty (Queue [] [1, 2, 3]) ~> False" $
      isEmpty (Queue [] ([1, 2, 3] :: [Int])) `shouldBe` False
    it "isEmpty (Queue [1] []) ~> False" $
      isEmpty (Queue [1] ([] :: [Int])) `shouldBe` False
    it "enqueue (enqueue (enqueue emptyQueue 1) 2) 3 ~> Queue [3, 2, 1] []" $
      enqueue (enqueue (enqueue createQueue one) 2) 3 `shouldBe` Queue [3, 2, 1] []
    it "dequeue (enqueue (enqueue (enqueue emptyQueue 1) 2) 3) ~> (1, Queue [] [2, 3])" $
      dequeue (enqueue (enqueue (enqueue createQueue one) 2) 3) `shouldBe` (1, Queue [] [2, 3])
    it "dequeue $ snd $ dequeue (enqueue (enqueue (enqueue createQueue 1) 2) 3) ~> (2, Queue [] [3])" $
      (dequeue $ snd $ dequeue (enqueue (enqueue (enqueue createQueue one) 2) 3)) `shouldBe` (2, Queue [] [3])