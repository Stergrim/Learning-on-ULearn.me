{-# LANGUAGE TypeApplications #-}

module CountingSortClassesSpec where

import Test.Hspec
import Test.QuickCheck

import CountingSortClasses
import Data.Array

main = hspec spec

spec :: Spec
spec = do
  describe "test" $ do
    it "test [(1,123)] [(56::Int)] 0 ~> [(0,123)]" $
      test [(1,123)] [(56::Int)] 0 `shouldBe` [(0,123)]
    it "test [(0, 34), (1, 65), (2, 432), (3, 234)] ([0..5] :: [Int]) 2 ~> [(0,0),(1,1),(2,432),(3,3),(4,4),(5,5)]" $
      test [(0, 34), (1, 65), (2, 432), (3, 234)] ([0..5] :: [Int]) 2 `shouldBe` [(0,0),(1,1),(2,432),(3,3),(4,4),(5,5)]
    it "test [(0, 0), (1, 1), (2, 2)] (array (0, 3) [(0, 10), (1, 11), (2, 12), (3, 13)]) 1 ~> [(0,10),(1,1),(2,12),(3,13)]" $
      test [(0, 0), (1, 1), (2, 2)] a 1 `shouldBe` [(0,10),(1,1),(2,12),(3,13)]
        where
          a = (array (0, 3) [(0, 10), (1, 11), (2, 12), (3, 13)]) :: Array Int Int