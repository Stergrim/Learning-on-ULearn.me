{-
   Эти два расширения нужны для того, чтобы создать instace'ы класса
   `IntArray` для полиморфных типов с несколькими параметрами.
-}
{-# LANGUAGE FlexibleInstances, AllowAmbiguousTypes #-}

-- Включает использование переменных типа, объявленных в типе функции
-- внутри тела этой функции (нужно в test)
{-# LANGUAGE ScopedTypeVariables #-}

module CountingSortClasses where

{-
  Вы можете использовать ключевое слово qualified при подключении модулей,
  чтобы компилятор явно требовал указание имени модуля для всех функций из
  этого модуля. Например, если вы подключили модуль Data.IntMap так:

  import qualified Data.IntMap as Map

  то к каждой функции нужно будет обращаться с префиксом `Map.`, например Map.toList.

  Это может понадобится, если в разных модулях встречаются функции с одинаковыми
  именами.
-}

-- Вы можете изменить в этом классе всё, кроме имени IntArray
class IntArray a where
  f1 :: ...      -- создать из списка пар [(index, value)]
  f2 :: ...      -- преобразовать в список пар [(index, value)]
  f3 :: ...      -- получить элемент по индексу
  f4 :: ...      -- обновить элемент по индексу

-- instance IntArray [Int] where
-- ...

-- Тестовая функция. Чтобы тесты прошли, просто переименуйте
-- функции f1, f2, f3, f4 в соответствии с объявленным вами классом IntArray
test :: forall l. IntArray l => [(Int, Int)] -> l -> Int -> [(Int, Int)]
test xs array i = f2 newArray
  where
    xsArray :: l
    xsArray = f1 xs

    x :: Int
    x = f3 xsArray i

    newArray :: l
    newArray = f4 array i x