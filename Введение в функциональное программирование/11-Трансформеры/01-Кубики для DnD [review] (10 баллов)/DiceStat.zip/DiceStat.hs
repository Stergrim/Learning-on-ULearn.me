module DiceStat where

-- Функция, генерирующая статистику
buildDiceStat :: [Int] -> Int -> IO [(Int,Double)]
buildDiceStat = undefined
