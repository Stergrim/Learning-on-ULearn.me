module DiceUtils where

import System.IO
import Control.Monad

--------------------------------------------------------------
-- Вывод гистограммы

formatInt :: Int -> Char -> Int -> String
formatInt width ch n = 
  let nS = show n
  in replicate (width - length nS) ch ++ nS

formatPercent :: Double -> String
formatPercent p =
  let 
    temp = round $ p * 10000.0 :: Int 
    entier = temp `div` 100
    frac = temp `mod` 100
  in
    formatInt 2 ' ' entier ++ "." ++ formatInt 2 '0' frac ++ "%"

drawHist :: Int -> [(Int,Double)] -> IO ()
drawHist maxWidth l = do
  let 
    maxWidth' = fromIntegral maxWidth :: Double
    maxPercent = maximum $ map snd l
  forM_ l (\(v,p) -> putStrLn $
    formatInt 3 ' ' v ++ " - " ++ formatPercent p ++ " |" ++
    replicate (round $ maxWidth' * p / maxPercent) '*'
    )

