module DiceStatSpec where

import Test.Hspec
import Test.QuickCheck

import Control.Monad
import Data.List

import DiceStat

test1 = [4,6,20] 
ans1 = [(3,2.0666e-3),(4,6.2782e-3),(5,1.24588e-2),(6,2.08864e-2),(7,2.90842e-2),(8,3.74544e-2),(9,4.36678e-2),(10,4.78294e-2),(11,5.00962e-2),(12,4.99538e-2),(13,4.99088e-2),(14,5.0018e-2),(15,5.01238e-2),(16,5.00466e-2),(17,5.00034e-2),(18,5.00066e-2),(19,5.01822e-2),(20,5.00332e-2),(21,5.01978e-2),(22,4.99948e-2),(23,4.79368e-2),(24,4.34388e-2),(25,3.73796e-2),(26,2.91774e-2),(27,2.09006e-2),(28,1.25422e-2),(29,6.2438e-3),(30,2.0898e-3)]

test2 = [4,4,12]
ans2 = [(3,5.1926e-3),(4,1.56822e-2),(5,3.11926e-2),(6,5.1928e-2),(7,6.77468e-2),(8,7.80754e-2),(9,8.32652e-2),(10,8.33652e-2),(11,8.3495e-2),(12,8.35686e-2),(13,8.33552e-2),(14,8.34238e-2),(15,7.80682e-2),(16,6.74708e-2),(17,5.20632e-2),(18,3.13168e-2),(19,1.5556e-2),(20,5.2344e-3)]

test3 = [8,10,12]
ans3 = [(3,1.0476e-3),(4,3.1326e-3),(5,6.266e-3),(6,1.03432e-2),(7,1.57122e-2),(8,2.18762e-2),(9,2.91656e-2),(10,3.75868e-2),(11,4.5744e-2),(12,5.41904e-2),(13,6.15504e-2),(14,6.79122e-2),(15,7.18798e-2),(16,7.39614e-2),(17,7.40316e-2),(18,7.17788e-2),(19,6.7606e-2),(20,6.12962e-2),(21,5.42254e-2),(22,4.57596e-2),(23,3.74244e-2),(24,2.91978e-2),(25,2.18766e-2),(26,1.5624e-2),(27,1.04214e-2),(28,6.235e-3),(29,3.1272e-3),(30,1.0276e-3)]


tasks = [(test1,ans1), (test2,ans2), (test3,ans3)]

throwNum = 100000
relEps = 0.20

checkFreqs :: [(Int,Double)] -> [(Int,Double)] -> Bool
checkFreqs ans out = 
  all (<= relEps) $ zipWith (\(_,a) (_,b) -> abs (a-b) / max (abs a) (abs b)) ans out

checkDistr :: [(Int,Double)] -> [(Int,Double)] -> SpecWith ()
checkDistr ans out' = do
  let 
    out = sort out'
    sAns = map fst ans
    sOut = map fst out
  it "distribution length"     $ length out `shouldBe` length ans
  it "distribution sums"       $ sOut `shouldBe` sAns
  it "distribution frequences" $ checkFreqs ans out `shouldBe` True
  
spec :: Spec
spec = 
  foldM (\_ (num,(test,ans)) -> 
    describe ("Test #" ++ show num ++ ": " ++ show test) $ do
      out <- runIO $ buildDiceStat test throwNum
      checkDistr ans out) undefined $
      zip [1..] tasks     
      
main :: IO ()      
main = hspec spec

      
