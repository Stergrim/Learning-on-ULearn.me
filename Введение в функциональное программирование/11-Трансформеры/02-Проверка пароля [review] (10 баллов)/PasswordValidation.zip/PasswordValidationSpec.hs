module PasswordValidationSpec where

import Test.Hspec
import Test.QuickCheck
import Control.Monad.Reader
import Control.Monad.Writer

import PasswordValidation

getVerdict :: String -> (Bool, [String])
getVerdict = runValidation . isValid

getVerdictUsingBase :: String -> [String] -> (Bool, [String])
getVerdictUsingBase password base =
  runReader (runWriterT $ runValidationT $ isValid password) base

main = hspec spec

spec :: Spec
spec = do
  describe "isValid" $ do
    it "isValid \"secure123.\" = (True,[\"Password is not compromised\"])" $
      getVerdict "secure123." `shouldBe` (True,["Password is not compromised"])
    it "isValid \"secure123\" = (False,[\"Password is not compromised\"])" $
      getVerdict "secure123" `shouldBe` (False,["Password is not compromised"])
    it "isValid \"secure....\" = (False,[\"Password is not compromised\"])" $
      getVerdict "secure...." `shouldBe` (False,["Password is not compromised"])
    it "isValid \"1234\" = (False,[\"Password is compromised\"])" $
      getVerdict "1234" `shouldBe` (False,["Password is compromised"])
    it "isValid \"1234\" = (False,[\"Password is compromised\"])" $
      getVerdict "1234" `shouldBe` (False,["Password is compromised"])
    it "isValid \"qwer1234.\" = (True,[\"Password is not compromised\"])" $
      getVerdict "qwer1234." `shouldBe` (True,["Password is not compromised"])
    it "isValid \"qwer1234.\" = (False,[\"Password is compromised\"]) -- if \"qwer1234.\" is compromised" $
      getVerdictUsingBase "qwer1234." ["qwer1234."] `shouldBe` (False,["Password is compromised"])