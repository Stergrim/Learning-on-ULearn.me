{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module PasswordValidation where

import Data.Char
import Control.Monad.Reader
import Control.Monad.Writer

newtype ValidationT a = ValidationT
  -- Тип должен позволять:
  -- - считывать базу с плохими паролями с помощью Reader
  -- - Писать логи-массивы строк
  --                        Тип лога
  --                          vvv
  { runValidationT :: WriterT ... ... a }
  --                              ^^^
  --            Монада для "скрещивания" с Writer'ом
  deriving
    -- Делаем тип монадой
    ( Functor
    , Applicative
    , Monad
    -- Добавляем ValidationT в эти классы, чтобы в функциях,
    -- работающих в ValidationT были доступны вспомогательные
    -- функции Reader и Writer
    , MonadWriter [String]
    --            ^^^^^^^^
    --            Тип лога
    , MonadReader [String]
    --            ^^^^^^^^
    --            Тип базы
    )

isStrong :: String -> Bool
isStrong password = length password >= 8
            && any isAlpha password
            && any isNumber password
            && any isPunctuation password

-- Cчитывает базу скомпрометированных паролей
-- Проверяет, что среди них нет пароля-аргумента
-- Записывает в лог результат проверки "Password is {not) compromised"
isCompromised :: String -> ValidationT Bool
isCompromised password = undefined

-- Проверяет, что пароль хороший с помощью функций isStrong и isCompromised
isValid :: String -> ValidationT Bool
isValid password = undefined

-- Мини-база плохих паролей
badPasswords = ["qwer", "qwerty", "qwer1234", "1234qwer", "1234", "12345678"]

-- Функция для извлечения результатов проверки
runValidation :: ValidationT a -> (a, [String])
runValidation validationT = runReader (runWriterT $ runValidationT validationT) badPasswords