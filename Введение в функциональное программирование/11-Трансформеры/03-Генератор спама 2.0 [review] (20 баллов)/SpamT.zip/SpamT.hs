{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module SpamT where

import Data.List
import Data.Maybe
import Control.Monad.Reader
import Control.Monad.State
import Control.Monad.Writer
import Prelude hiding (id)
import Person (Person (..), PersonId, persons)

-- Тип для сбора статистики
data PersonSearchStats = PersonSearchStats
  -- количество обработанных персон, состоящих в браке
  { marriedPersonsCount :: Integer
  -- количество обработанных холостых персон
  , singlePersonsCount :: Integer
  } deriving (Eq, Show)

-- Тип возвращаемого значения функций для обработки персон,
-- составленный с помощью трансформеров WriterT, StateT и монады Reader
newtype SpamT a = SpamT
  { runSpamT :: NotImplemented }
  deriving
    -- Делаем SpamT монадой
    ( Functor
    , Applicative
    , Monad
    -- Добавляем SpamT в классы, которые позволяют использовать
    -- вспомогательные функции Reader, Writer и State
    , MonadReader [Person]
    , MonadWriter [String]
    , MonadState PersonSearchStats
    )

-- Функция, извлекающая из SpamT результат вычислений, состояние и лог
runSpam :: SpamT a -> ((a, PersonSearchStats), [String])
runSpam spamT = error "not implemented"

-- Поиск персоны по id. В неё нужно будет добавить логгирование
findById :: PersonId -> SpamT (Maybe Person)
findById pId = error "not implemented"

-- Функция, генерирующая письмо по id.
-- В ней нужно подсчитывать статистику и писать сообщения в лог
processPerson :: PersonId -> SpamT (Maybe String)
processPerson personId = error "not implemented"

-- Функция, которая обрабатывает все id из списка, выкидывая
-- результат по ненайденным id
processPersons :: [PersonId] -> SpamT [String]
processPersons personsIds = error "not implemented"

-- Функция для вывода статистики
showStat :: SpamT a -> IO ()
showStat spamT = error "not implemented"

-- Функция для вывода лога
showLog :: SpamT a -> IO ()
showLog spamT = error "not implemented"