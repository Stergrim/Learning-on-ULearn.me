module SpamTSpec where

import Test.Hspec
import Test.QuickCheck

import SpamT
import Control.Monad.Reader
import Control.Monad.State
import Control.Monad.Writer
import Prelude hiding (id)
import Person (Person (..), PersonId, Sex (..), persons)

main = hspec spec

getStat :: SpamT a -> PersonSearchStats
getStat = snd . fst . runSpam

getResult :: SpamT a -> a
getResult = fst . fst . runSpam

getLog :: SpamT a -> [String]
getLog = snd . runSpam

spec :: Spec
spec = do
  describe "findById" $ do
    it "findById 1 = Just (Person 1 Иванов ...)" $
      getResult (findById 1) `shouldBe` Just (Person 1 "Иванов" "Иван" "Иванович" Male Nothing)
    it "getLog (findById  1) = [\"Looking for a person '1'\"]" $
      getLog (findById 1) `shouldBe` ["Looking for a person '1'"]
    it "getStat (findById  1) = {marriedPersonsCount = 0, singlePersonsCount = 0}" $
      getStat (findById 1) `shouldBe` PersonSearchStats {marriedPersonsCount = 0, singlePersonsCount = 0}
    it "findById 10 = Nothing" $
      getResult (findById 10) `shouldBe` Nothing

  describe "processPerson" $ do
    it "processPerson 2 = \"Уважаемые Петр Петрович и Екатерина Алексеевна!...\"" $
      getResult (processPerson 2) `shouldBe` Just "Уважаемые Петр Петрович и Екатерина Алексеевна!\nРазрешите предложить вам наши услуги."
    it "processPerson 1 = \"Уважаемый Иван Иванович!...\"" $
      getResult (processPerson 1) `shouldBe` Just "Уважаемый Иван Иванович!\nРазрешите предложить Вам наши услуги."
    it "processPerson 10 = Nothing" $
      getResult (processPerson 10) `shouldBe` Nothing
    it "getLog $ processPerson 10 = [\"Looking for a person '10'\", \"Person '10' is not found\"]" $
      getLog (processPerson 10) `shouldBe` ["Looking for a person '10'", "Person '10' is not found"]
    it "getLog $ processPerson 3 = [\"Looking for a person '3'\", \"Person '3' is 'Фаридовна'\"]" $
      getLog (processPerson 3) `shouldBe` ["Looking for a person '3'", "Person '3' is 'Соловьева'"]
    it "getLog $ processPerson 4 = [\"Looking for a person '4'\", \"Person '4' is 'Ивановна'\", \"Looking for a person '8'\"]" $
      getLog (processPerson 4) `shouldBe` ["Looking for a person '4'", "Person '4' is 'Кузнецова'", "Looking for a person '8'"]
    it "getStat (processPerson 4) = {marriedPersonsCount = 2, singlePersonsCount = 0}" $
      getStat (processPerson 4) `shouldBe` PersonSearchStats {marriedPersonsCount = 1, singlePersonsCount = 0}
    it "getStat (processPerson 6) = {marriedPersonsCount = 0, singlePersonsCount = 1}" $
      getStat (processPerson 6) `shouldBe` PersonSearchStats {marriedPersonsCount = 0, singlePersonsCount = 1}
    it "getStat (processPerson 16) = {marriedPersonsCount = 0, singlePersonsCount = 0}" $
      getStat (processPerson 16) `shouldBe` PersonSearchStats {marriedPersonsCount = 0, singlePersonsCount = 0}

  describe "processPersons" $ do
    it "processPersons [7,9,12] = [\"Уважаемые Екатерина Алексеевна и Петр Петрович!...\",\"Уважаемый Юрий Васильевич!...\"]" $
      getResult (processPersons [7,9,12]) `shouldBe` ["Уважаемые Екатерина Алексеевна и Петр Петрович!\nРазрешите предложить вам наши услуги.","Уважаемый Юрий Васильевич!\nРазрешите предложить Вам наши услуги."]
    it "getLog $ processPersons [7,9,12] = [\"Loking for a person '7'\", ... \"Person '12' is not found\"]" $
      getLog (processPersons [7,9,12]) `shouldBe` ["Looking for a person '7'","Person '7' is 'Петрова'","Looking for a person '2'","Looking for a person '9'","Person '9' is 'Антонов'","Looking for a person '12'","Person '12' is not found"]
    it "getStat $ processPersons [7,9,12,2,5,1]] = {marriedPersonsCount = 4, singlePersonsCount = 3}" $
      getStat (processPersons [7,9,12,2,5,1]) `shouldBe` PersonSearchStats {marriedPersonsCount = 2, singlePersonsCount = 3}

  describe "helpers" $ do
    it "showStat should work" $ do
      showStat (findById 1)
      True`shouldBe` True
    it "showLog should work" $ do
      showLog (findById 1)
      True`shouldBe` True
