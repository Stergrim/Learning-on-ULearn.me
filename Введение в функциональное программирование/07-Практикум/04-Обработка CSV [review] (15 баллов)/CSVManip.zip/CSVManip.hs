module CSVManip where

-- Обрабатывает таблицу в формате CSV
processCSV :: String -> String -> String -> IO()
processCSV = undefined
