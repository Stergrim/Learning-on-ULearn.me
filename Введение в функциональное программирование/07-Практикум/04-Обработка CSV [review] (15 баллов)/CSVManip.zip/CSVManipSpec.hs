module CSVManipSpec where

import Test.Hspec
import Test.QuickCheck

import Data.List

import CSVManip

compareFiles :: String -> String -> IO Bool
compareFiles f1 f2 = do
  c1 <- lines <$> readFile f1
  c2 <- lines <$> readFile f2
  return $ c1 == c2

main = hspec spec

doTest :: [Char] -> IO ()
doTest test = do      
  let 
    workingDirectory = "./Tests/"
    testIn = workingDirectory ++ test ++ ".csv"
    testCh = workingDirectory ++ test ++ "_ch.txt"
    expected = workingDirectory ++ test ++ ".out"
    actual = workingDirectory ++ "actual.txt"
  processCSV testIn testCh actual
  res <- compareFiles expected actual
  res `shouldBe` True

spec :: Spec
spec = 
  describe "processing CSV" $ do
    it "test1" $ doTest "01"
    it "test2" $ doTest "02"      
    it "test3" $ doTest "03"      
    it "test4" $ doTest "04"      
