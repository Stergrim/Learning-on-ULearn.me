module SeaBattle where

-- Описанные в задаче типы
import Dto

-- Проверяет расстановку кораблей
checkFleet :: Fleet -> [Error]
checkFleet = undefined