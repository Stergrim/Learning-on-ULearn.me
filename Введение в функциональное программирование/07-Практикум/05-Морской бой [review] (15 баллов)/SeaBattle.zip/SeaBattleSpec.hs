module SeaBattleSpec where

import Test.Hspec

import Data.List
import Data.Either

import SeaBattle
import Dto

isCrossing :: Error -> Bool 
isCrossing (TooClose _ _) = True
isCrossing _ = False

computeCheck :: Fleet -> [Error] -> Bool
computeCheck f ans = ansC' == outC' && ansO' == outO'
  where 
    separateErrors :: [Error] -> ([Error],[Error])
    separateErrors = partition isCrossing

    out = checkFleet f
    (outC,outO) = separateErrors out
    (ansC,ansO) = separateErrors ans

    ansO' = sort ansO
    ansC' = sort $ map (\(TooClose s1 s2) -> sort [s1,s2]) ansC
    outO' = sort outO
    outC' = sort $ map (\(TooClose s1 s2) -> sort [s1,s2]) outC

main = hspec spec

spec :: Spec
spec = do
  describe "Good fleets" $ do
    it "fleet01" $ computeCheck fleet01 ans01 `shouldBe` True
    it "fleet02" $ computeCheck fleet02 ans02 `shouldBe` True
  describe "Bad fleets: too small total number" $ do
    it "fleet03" $ computeCheck fleet03 ans03 `shouldBe` True
    it "fleet04" $ computeCheck fleet04 ans04 `shouldBe` True
    it "fleet05" $ computeCheck fleet05 ans05 `shouldBe` True
    it "fleet06" $ computeCheck fleet06 ans06 `shouldBe` True
  describe "Bad fleets: 10 ships, but wrong number in groups" $ do
    it "fleet07" $ computeCheck fleet07 ans07 `shouldBe` True
    it "fleet08" $ computeCheck fleet08 ans08 `shouldBe` True
    it "fleet09" $ computeCheck fleet09 ans09 `shouldBe` True
  describe "Bad fleets: 10 ships, wrong 2-ship configuration" $ do
    it "fleet10" $ computeCheck fleet10 ans10 `shouldBe` True
    it "fleet11" $ computeCheck fleet11 ans11 `shouldBe` True
    it "fleet12" $ computeCheck fleet12 ans12 `shouldBe` True
    it "fleet13" $ computeCheck fleet13 ans13 `shouldBe` True
  describe "Bad fleets: 10 ships, wrong 3-ship configuration" $ do
    it "fleet14" $ computeCheck fleet14 ans14 `shouldBe` True
    it "fleet15" $ computeCheck fleet15 ans15 `shouldBe` True
    it "fleet16" $ computeCheck fleet16 ans16 `shouldBe` True
    it "fleet17" $ computeCheck fleet17 ans17 `shouldBe` True
    it "fleet18" $ computeCheck fleet18 ans18 `shouldBe` True
  describe "Bad fleets: 10 ships, wrong 4-ship configuration" $ do
    it "fleet19" $ computeCheck fleet19 ans19 `shouldBe` True
    it "fleet20" $ computeCheck fleet20 ans20 `shouldBe` True
    it "fleet21" $ computeCheck fleet21 ans21 `shouldBe` True
    it "fleet22" $ computeCheck fleet22 ans22 `shouldBe` True
    it "fleet23" $ computeCheck fleet23 ans23 `shouldBe` True
    it "fleet24" $ computeCheck fleet24 ans24 `shouldBe` True
    it "fleet25" $ computeCheck fleet25 ans25 `shouldBe` True
  describe "Bad fleets: 10 ships, several ships with bad configuration" $ do
    it "fleet26" $ computeCheck fleet26 ans26 `shouldBe` True
    it "fleet27" $ computeCheck fleet27 ans27 `shouldBe` True
  describe "Bad fleets: 10 ships, ships outside field" $ do
    it "fleet28" $ computeCheck fleet28 ans28 `shouldBe` True
    it "fleet29" $ computeCheck fleet29 ans29 `shouldBe` True
    it "fleet30" $ computeCheck fleet30 ans30 `shouldBe` True
    it "fleet31" $ computeCheck fleet31 ans31 `shouldBe` True
    it "fleet32" $ computeCheck fleet32 ans32 `shouldBe` True
  describe "Bad fleets: too large total number" $ do
    it "fleet33" $ computeCheck fleet33 ans33 `shouldBe` True
    it "fleet34" $ computeCheck fleet34 ans34 `shouldBe` True
    it "fleet35" $ computeCheck fleet35 ans35 `shouldBe` True
    it "fleet36" $ computeCheck fleet36 ans36 `shouldBe` True
    it "fleet37" $ computeCheck fleet37 ans37 `shouldBe` True
  describe "Bad fleets: too long ships" $ do
    it "fleet38" $ computeCheck fleet38 ans38 `shouldBe` True
    it "fleet39" $ computeCheck fleet39 ans39 `shouldBe` True
  describe "Bad fleets: crossing ships" $ do
    it "fleet40" $ computeCheck fleet40 ans40 `shouldBe` True
    it "fleet41" $ computeCheck fleet41 ans41 `shouldBe` True
    it "fleet42" $ computeCheck fleet42 ans42 `shouldBe` True
    it "fleet43" $ computeCheck fleet43 ans43 `shouldBe` True
    it "fleet44" $ computeCheck fleet44 ans44 `shouldBe` True
    it "fleet45" $ computeCheck fleet45 ans45 `shouldBe` True
    it "fleet46" $ computeCheck fleet46 ans46 `shouldBe` True
  describe "Bad fleets: complex situations" $ do
    it "fleet47" $ computeCheck fleet47 ans47 `shouldBe` True
    it "fleet48" $ computeCheck fleet48 ans48 `shouldBe` True
    it "fleet49" $ computeCheck fleet49 ans49 `shouldBe` True

----------------------------
{- Good fleet
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet01 :: Fleet
fleet01 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans01 :: [Error]
ans01 = []

----------------------------
{- Good fleet
 .o......o.
 .o........
 .......oo.
 .ooo......
 ..........
 o..o..oo..
 ...o......
 ...o.o..o.
 .o.o....o.
 ...o....o.
-}
fleet02 :: Fleet
fleet02 =
  [ ("S1", [(2,2), (1,2)])
  , ("S2", [(1,9)])
  , ("S3", [(3,9), (3,8)])
  , ("S4", [(4,4), (4,2), (4,3)])
  , ("S5", [(6,1)])
  , ("S6", [(6,7), (6,8)])
  , ("S7", [(9,2)])
  , ("S8", [(8,6)])
  , ("S9", [(8,9), (10,9), (9,9)])
  , ("S10", [(10,4), (9,4), (7,4), (8,4)])
  ]
ans02 :: [Error]
ans02 = []

----------------------------
{- Bad fleet - one 1-ship is lost
 x.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet03 :: Fleet
fleet03 =
  [ -- ("S1", [(1,1)])
    ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans03 :: [Error]
ans03 = [WrongTotal, TooFew 1]

----------------------------
{- Bad fleet - two 2-ships are lost
 o.xx.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....xx.o
-}
fleet04 :: Fleet
fleet04 =
  [ ("S1", [(1,1)])
--  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
--  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans04 :: [Error]
ans04 = [WrongTotal, TooFew 2]

----------------------------
{- Bad fleet - two 3-ships are lost
 o.oo.....o
 ..........
 .........o
 ..x.x....o
 o.x.x.....
 o.x.x.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet05 :: Fleet
fleet05 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
--  , ("S5", [(4,3), (6,3), (5,3)])
--  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans05 :: [Error]
ans05 = [WrongTotal, TooFew 3]

----------------------------
{- Bad fleet: no 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 x.o.o.....
 x.o.o.....
 x.........
 x.........
 ..........
 o.....oo.o
-}
fleet06 :: Fleet
fleet06 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
--  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans06 :: [Error]
ans06 = [WrongTotal, TooFew 4]
  
----------------------------
{- Bad fleet: totally 10 ships, 5 1-ships, 0 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 x.o.o.....
 x.o.o.....
 x.........
 o.........
 ..........
 o.....oo.o
-}
fleet07 :: Fleet
fleet07 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
--  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S7", [(8,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans07 :: [Error]
ans07 = [TooFew 4, TooMany 1]

----------------------------
{- Bad fleet: totally 10 ships, 6 1-ships, 1 3-ship, 0 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.x....o
 x.o.o.....
 x.o.x.....
 x.........
 o.........
 ..........
 o.....oo.o
-}
fleet08 :: Fleet
fleet08 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
--  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S6", [(6,5)])
--  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S7", [(8,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]    
ans08 :: [Error]
ans08 = [TooFew 3, TooFew 4, TooMany 1]

----------------------------
{- Bad fleet: totally 10 ships, 1 3-ship, 2 4-ships
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o...+.....
 o.........
 ..........
 o.....oo.o
-}
fleet09 :: Fleet
fleet09 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
--  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S6", [(7,5), (5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans09 :: [Error]
ans09 = [TooFew 3, TooMany 4]

----------------------------
{- Bad fleet: bad configuration of 2-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o....+.+.o
-}
fleet10 :: Fleet
fleet10 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,6)])
  , ("S10", [(10,10)])
  ]  
ans10 :: [Error]
ans10 = [WrongConfiguration "S9"]

----------------------------
{- Bad fleet: bad configuration of 2-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o......+..
 ..........
 o......+.o
-}
fleet11 :: Fleet
fleet11 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (8,8)])
  , ("S10", [(10,10)])
  ]  
ans11 :: [Error]
ans11 = [WrongConfiguration "S9"]

----------------------------
{- Bad fleet: bad configuration of 2-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ......+...
 o......+.o
-}
fleet12 :: Fleet
fleet12 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (9,7)])
  , ("S10", [(10,10)])
  ]  
ans12 :: [Error]
ans12 = [WrongConfiguration "S9"]

----------------------------
{- Bad fleet: bad configuration of 2-ship, coinciding cells
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ......Ж...
 o........o
-}
fleet13 :: Fleet
fleet13 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(9,7), (9,7)]) -- !!!
  , ("S10", [(10,10)])
  ]  
ans13 :: [Error]
ans13 = [WrongConfiguration "S9"]

----------------------------
{- Bad fleet: bad configuration of 3-ship
 o.oo.....o
 ..........
 .........o
 ..o.+....o
 o.o.+.....
 o.o.......
 o...+.....
 o.........
 ..........
 o.....oo.o
-}
fleet14 :: Fleet
fleet14 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (7,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans14 :: [Error]
ans14 = [WrongConfiguration "S6"]

----------------------------
{- Bad fleet: bad configuration of 3-ship
 o.oo.....o
 ..........
 .........o
 ..o.+....o
 o.o... .....
 o.o.+.....
 o...+.....
 o.........
 ..........
 o.....oo.o
-}
fleet15 :: Fleet
fleet15 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(6,5), (7,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans15 :: [Error]
ans15 = [WrongConfiguration "S6"]

----------------------------
{- Bad fleet: bad configuration of 3-ship
 o.oo.....o
 ..........
 .........o
 ..o.+....o
 o.o.+......
 o.o..+....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet16 :: Fleet
fleet16 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,6), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans16 :: [Error]
ans16 = [WrongConfiguration "S6"]

----------------------------
{- Bad fleet: bad configuration of 3-ship
 o.oo.....o
 ..........
 .........o
 ..o.+....o
 o.o.++....
 o.o.......
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet17 :: Fleet
fleet17 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (5,6), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]    
ans17 :: [Error]
ans17 = [WrongConfiguration "S6"]

----------------------------
{- Bad fleet: bad configuration of 3-ship
 o.oo.....o
 ..........
 .........o
 ..o.+....o
 o.o.Ж.....
 o.o.......
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet18 :: Fleet
fleet18 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (5,5), (4,5)]) -- !!!
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans18 :: [Error]
ans18 = [WrongConfiguration "S6"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .+++.+....
 ..........
 o.....oo.o
-}
fleet19 :: Fleet
fleet19 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (8,4), (8,6)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans19 :: [Error]
ans19 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .+.+.+.+..
 ..........
 o.....oo.o
-}
fleet20 :: Fleet
fleet20 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,8), (8,4), (8,6)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]    
ans20 :: [Error]
ans20 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .++.......
 ..++......
 o.....oo.o
-}
fleet21 :: Fleet
fleet21 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (9,3), (9,4)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]      
ans21 :: [Error]
ans21 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ......o...
 .++.......
 .++.......
 ......oo.o
-}
fleet22 :: Fleet
fleet22 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (9,3), (9,2)])
  , ("S8", [(7,7)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ] 
ans22 :: [Error]
ans22 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .+++......
 ..+.......
 o.....oo.o
-}
fleet23 :: Fleet
fleet23 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (9,3), (8,4)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]   
ans23 :: [Error]
ans23 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .++ ......
 ..+.......
 o..+..oo.o
-}
fleet24 :: Fleet
fleet24 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (9,3), (10,4)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans24 :: [Error]
ans24 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: wrong configuration of 4-ship - coinciding cells
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 ..o.o.....
 ..o.o.....
 ..........
 .+Ж+......
 ..........
 o.....oo.o
-}
fleet25 :: Fleet
fleet25 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(8,2), (8,3), (8,4), (8,3)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans25 :: [Error]
ans25 = [WrongConfiguration "S7"]

----------------------------
{- Bad fleet: 2 ships with bad configuration
 o.oo.....o
 ..........
 ..+......+
 ....o...+.
 o.+.o.....
 o.+.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet26 :: Fleet
fleet26 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,9)])       -- !!!
  , ("S5", [(4,3), (6,3), (7,3)]) -- !!!
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans26 :: [Error]
ans26 = [WrongConfiguration "S4", WrongConfiguration "S5"]

----------------------------
{- Good fleet
 o.+......o
 ....+.....
 .........o
 +.o.o....o
 ..o.o.....
 +.o.o.....
 +.........
 .+........
 ..........
 o....+.+.o
-}
fleet27 :: Fleet
fleet27 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (2,5)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(4,1), (6,1), (7,1), (8,2)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,10)])
  , ("S10", [(10,8), (10,6)]) -- !!!
  ]  
ans27 :: [Error]
ans27 = [WrongConfiguration "S10", WrongConfiguration "S2", WrongConfiguration "S7" ]

----------------------------
{- Bad fleet: totally 10 ships, 1 ship partially outside field
 o.oo.....o
 ..........
 .........++
 ..o.o.....
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet28 :: Fleet
fleet28 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (3,11)]) -- !!!
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans28 :: [Error]
ans28 = [OutOfField "S4"]

----------------------------
{- Bad fleet: totally 10 ships, 1 ship totally outside field
 o.oo.....o
 ..........
 ..........++
 ..o.o.....
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet29 :: Fleet
fleet29 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,12), (3,11)]) -- !!!
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans29 :: [Error]
ans29 = [OutOfField "S4"]

----------------------------
{- Bad fleet: totally 10 ships, 1 ship partially, 1 ship totally outside field
 o.oo.....o
 ..........
 .........++
 ..o.o.....
+..o.o.....
+..o.o.....
+..........
+..........
 ..........
 o.....oo.o
-}
fleet30 :: Fleet
fleet30 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (3,11)]) -- !!!
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,0), (8,0), (7,0), (6,0)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans30 :: [Error]
ans30 = [OutOfField "S4", OutOfField "S7"]

----------------------------
{- Bad fleet: totally 10 ships, 1 ship partially, 2 ship totally outside field
           + 
 o.oo......
 ..........
 .........o
 ..o......o
 o.o.......
 o.o.......
 o.........
 o........+++
 ..........
 o........o
       ++
-}
fleet31 :: Fleet
fleet31 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(0,11)])          -- !!!
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(8,12), (8,10), (8,11)])  -- !!!
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(11,8), (11,7)])  -- !!!
  , ("S10", [(10,10)])
  ]
ans31 :: [Error]
ans31 = [OutOfField "S3", OutOfField "S6", OutOfField "S9"]

----------------------------
{- Bad fleet: totally 10 ships, 1 ship sufficiently totally outside field
 o.oo.....o
 ..........
 .........o
 ..o......o
 o.o.......
 o.o.......
 o.........
 o............+++
 ..........
 o.....oo.o
-}
fleet32 :: Fleet
fleet32 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(8,14), (8,15), (8,16)])  -- !!!
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])  
  , ("S10", [(10,10)])
  ]
ans32 :: [Error]
ans32 = [OutOfField "S6"]

----------------------------
{- Bad fleet: 11 ships, one 1-ship more
 o.oo.....o
 ......+...
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet33 :: Fleet
fleet33 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(2,7)])
  ]
ans33 :: [Error]
ans33 = [WrongTotal, TooMany 1]

----------------------------
{- Bad fleet: 11 ships, one 2-ship more
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o...+.
 o.......+.
 o.........
 ..........
 o.....oo.o
-}
fleet34 :: Fleet
fleet34 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(7,9), (6,9)])
  ]  
ans34 :: [Error]
ans34 = [WrongTotal, TooMany 2]

----------------------------
{- Bad fleet: 11 ships, one 3-ship more
 o.oo.....o
 ..........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..+++.....
 o.....oo.o
-}
fleet35 :: Fleet
fleet35 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(9,3), (9,5), (9,4)])
  ]  
ans35 :: [Error]
ans35 = [WrongTotal, TooMany 3]

----------------------------
{- Bad fleet: 11 ships, one 4-ship more
 o.oo..+..o
 ......+...
 ......+..o
 ..o.o.+..o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet36 :: Fleet
fleet36 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(1,7), (2,7), (3,7), (4,7)])
  ]  
ans36 :: [Error]
ans36 = [WrongTotal, TooMany 4]

----------------------------
{- Bad fleet: 13 ships, two 1-ship more, one 2-ship more
 o.oo.....o
 .....++...
 +........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o....+....
 ..........
 o.....oo.o
-}
fleet37 :: Fleet
fleet37 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(3,1)])
  , ("S12", [(8,6)])
  , ("S13", [(2,6), (2,7)])
  ]  
ans37 :: [Error]
ans37 = [WrongTotal, TooMany 1, TooMany 2]

----------------------------
{- Bad fleet: too many ships, too long ship
 o.oo..+..o
 ......+...
 ......+..o
 ..o.o.+..o
 o.o.o.+...
 o.o.o.+...
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet38 :: Fleet
fleet38 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(1,7), (2,7), (3,7), (4,7), (5,7)]) -- !!!
  ]
ans38 :: [Error]
ans38 = [WrongTotal, WrongType "S11"]

----------------------------
{- Bad fleet: 10 ships, 2 too long ships
 o.oo..+...
 ......+...
 +.....+...
 +.o.o.+...
 +.o.o.+...
 +.o.o.+...
 +.....+...
 +.oo......
 ..........
 o.....oo.o
-}
fleet39 :: Fleet
fleet39 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(8,3), (8,4)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (4,1), (7,1), (6,1), (3,1)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(1,7), (2,7), (3,7), (4,7), (5,7), (6,7)]) -- !!!
  ]  
ans39 :: [Error]
ans39 = [ WrongType "S11", WrongType "S7", TooFew 1, TooFew 4]

----------------------------
{- Bad fleet: two crossing ships, touching by corners
 ..xx.....o
 .+........
 .........o
 ..o.o....o
 o.o.o.....
 o.o.o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet40 :: Fleet
fleet40 =
  [ ("S1", [(2,2)])        -- !!!
  , ("S2", [(1,3), (1,4)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans40 :: [Error]
ans40 = [TooClose "S1" "S2"]

----------------------------
{- Bad fleet: two crossing ships, touching by sides
 ..xx.....o
 ..+.......
 ..+......o
 ....o.....
 o.o.o.....
 o.o.o.....
 o.o.......
 o.........
 ..........
 o.....oo.o
-}
fleet41 :: Fleet
fleet41 =
  [ ("S1", [(3,10)])          
  , ("S2", [(1,3), (1,4)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(2,3), (3,3)]) -- !!!
  , ("S5", [(7,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans41 :: [Error]
ans41 = [TooClose "S2" "S4"]

----------------------------
{- Bad fleet: two crossing ships, touching by sides
 ..xx++...o
 ..........
 .........o
 ....o.....
 o.o.o.....
 o.o.o.....
 o.o.......
 o.........
 ..........
 o.....oo.o
-}
fleet42 :: Fleet
fleet42 =
  [ ("S1", [(3,10)])          
  , ("S2", [(1,3), (1,4)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(1,6), (1,5)]) -- !!!
  , ("S5", [(7,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans42 :: [Error]
ans42 = [TooClose "S2" "S4"]

----------------------------
{- Bad fleet: two crossing ships, imposing
 ..xЖ+....o
 ..........
 .........o
 ....o.....
 o.o.o.....
 o.o.o.....
 o.o.......
 o.........
 ..........
 o.....oo.o
-}
fleet43 :: Fleet
fleet43 =
  [ ("S1", [(3,10)])          
  , ("S2", [(1,3), (1,4)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(1,4), (1,5)]) -- !!!
  , ("S5", [(7,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]   
ans43 :: [Error]
ans43 = [TooClose "S2" "S4"]

----------------------------
{- Bad fleet: two crossing ships, coinciding
 ..ЖЖ.....o
 ..........
 .........o
 ....o.....
 o.o.o.....
 o.o.o.....
 o.o.......
 o.........
 ..........
 o.....oo.o
-}
fleet44 :: Fleet
fleet44 =
  [ ("S1", [(3,10)])          
  , ("S2", [(1,3), (1,4)]) -- !!!
  , ("S3", [(1,10)])
  , ("S4", [(1,4), (1,3)]) -- !!!
  , ("S5", [(7,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans44 :: [Error]
ans44 = [TooClose "S2" "S4"]

----------------------------
{- Bad fleet: two pairs of crossing ships
 o.oo.....o
 ..........
 ..........
 ..+xxx....
 o.+.......
 o.+.......
 o.........
 o.....x...
 ......x...
 o.....++.o
-}
fleet45 :: Fleet
fleet45 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(8,7), (9,7)])  -- !!! (2)
  , ("S5", [(4,3), (6,3), (5,3)]) -- !!! (1)
  , ("S6", [(4,4), (4,5), (4,6)]) -- !!! (1)
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)]) -- !!! (2)
  , ("S10", [(10,10)])
  ]  
ans45 :: [Error]
ans45 = [TooClose "S4" "S9", TooClose "S5" "S6"]

----------------------------
{- Bad fleet: one ship crosses two others
 o.oo.....o
 ..........
 ....+....o
 ..+.+....o
 ..+.+.....
 xxЖx......
 ..........
 ..........
 ..........
 o.....oo.o
-}
fleet46 :: Fleet
fleet46 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)])  -- !!!
  , ("S6", [(5,5), (3,5), (4,5)])  -- !!!
  , ("S7", [(6,1), (6,2), (6,3), (6,4)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]  
ans46 :: [Error]
ans46 = [TooClose "S5" "S7", TooClose "S6" "S7"]

----------------------------
{- Bad fleet, complex situation: bad configuration, outside field, crossing
 o.oo.....o
 ..........
 .........o
 ..+.+....o
xxx+x+.....
 ..+.+.....
 ..........
 ..........
 ..........
 o.....oo.o
-}
fleet47 :: Fleet
fleet47 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S5", [(4,3), (6,3), (5,3)]) -- !!!
  , ("S6", [(5,5), (6,5), (4,5)]) -- !!!
  , ("S7", [(5,0), (5,1), (5,2), (5,4)]) -- !!!
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  ]
ans47 :: [Error]
ans47 = [WrongConfiguration "S7", OutOfField "S7", TooClose "S5" "S7", TooClose "S6" "S7"]

----------------------------
{- Bad fleet, complex situation: wrong total number, wrong type, wrong configuration
 o.oo.....o
 ..........
 .........+
 ..o.+....+
 o.o.+xx.xx
 o.o.+..x..
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet48 :: Fleet
fleet48 =
  [ ("S1", [(1,1)])
  , ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])  -- !!!
  , ("S5", [(4,3), (6,3), (5,3)])
  , ("S6", [(5,5), (6,5), (4,5)]) -- !!!
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(5,5), (5,7), (6,8), (5,9), (5,10)]) -- !!!
  ]
ans48 :: [Error]
ans48 = [ WrongTotal, WrongType "S11", WrongConfiguration "S11"
        , TooClose "S11" "S4", TooClose "S6" "S11"]

----------------------------
{- Bad fleet, complex situation: wrong total number, bad group s,
      out of field, crossing
 ..oo.....o
 ..........
 .........+
 ....o....+xx
 o...o.....
 o...o.....
 o.........
 o.........
 ..........
 o.....oo.o
-}
fleet49 :: Fleet
fleet49 =
  [ ("S2", [(1,3), (1,4)])
  , ("S3", [(1,10)])
  , ("S4", [(3,10), (4,10)])
  , ("S6", [(5,5), (6,5), (4,5)])
  , ("S7", [(5,1), (8,1), (7,1), (6,1)])
  , ("S8", [(10,1)])
  , ("S9", [(10,8), (10,7)])
  , ("S10", [(10,10)])
  , ("S11", [(4,12), (4,11)])
  ]
ans49 :: [Error]
ans49 = [WrongTotal, TooFew 1, TooMany 2, TooFew 3, OutOfField "S11"
        , TooClose "S11" "S4"]