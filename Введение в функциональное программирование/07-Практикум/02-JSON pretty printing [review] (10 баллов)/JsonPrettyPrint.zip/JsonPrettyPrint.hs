module JsonPrettyPrint where

data JSON

-- | Prints JSON in one line
prettyPrint :: JSON -> String
prettyPrint = undefined

john :: JSON
john = undefined

todoList :: JSON
todoList = undefined

menuWidget :: JSON
menuWidget = undefined
