module JsonPrettyPrintIndentSpec where

import Test.Hspec
import Test.QuickCheck

import Data.List

import JsonPrettyPrintIndent

main = hspec spec

expectedJohn :: String
expectedJohn = intercalate "\n" $
  [ "{"
  , "  \"name\": \"John\","
  , "  \"age\": 30,"
  , "  \"temperature\": 36.6,"
  , "  \"car\": null,"
  , "  \"hasCat\": true,"
  , "  \"isMarried\": false"
  , "}"
  ]

expectedTodolist :: String
expectedTodolist = intercalate "\n" $
  [ "["
  , "  \"Wake up\","
  , "  \"Write Haskell\","
  , "  \"Go to bed\""
  , "]"
  ]

expectedMenuWidget :: String
expectedMenuWidget = intercalate "\n" $
  [ "{"
  , "  \"menu\": {"
  , "    \"id\": \"file\","
  , "    \"value\": \"File\","
  , "    \"popup\": {"
  , "      \"menuitem\": ["
  , "        {"
  , "          \"value\": \"New\","
  , "          \"onclick\": \"CreateNewDoc()\""
  , "        },"
  , "        {"
  , "          \"value\": \"Open\","
  , "          \"onclick\": \"OpenDoc()\""
  , "        },"
  , "        {"
  , "          \"value\": \"Close\","
  , "          \"onclick\": \"CloseDoc()\""
  , "        }"
  , "      ]"
  , "    }"
  , "  }"
  , "}"
  ]

spec :: Spec
spec = do
  describe "prettyPrint" $ do
    it "prints john as expected" $
      prettyPrint john `shouldBe` expectedJohn
    it "prints todo list as expected" $
      prettyPrint todoList `shouldBe` expectedTodolist
    it "prints menu widget as expected" $
      prettyPrint menuWidget `shouldBe` expectedMenuWidget
