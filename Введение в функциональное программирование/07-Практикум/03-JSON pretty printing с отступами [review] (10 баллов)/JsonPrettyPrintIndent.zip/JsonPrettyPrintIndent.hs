module JsonPrettyPrintIndent where

data JSON

-- | Prints JSON with pretty indentation
prettyPrint :: JSON -> String
prettyPrint = undefined

john :: JSON
john = undefined

todoList :: JSON
todoList = undefined

menuWidget :: JSON
menuWidget = undefined
