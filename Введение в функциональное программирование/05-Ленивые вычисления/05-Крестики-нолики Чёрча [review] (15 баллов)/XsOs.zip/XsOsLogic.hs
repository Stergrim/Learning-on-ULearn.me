module XsOsLogic where

import XsOsDtos

-- Пример создания строки поля
createRow :: Value -> Value -> Value -> Row
createRow x y z = \row -> case row of
  First -> x
  Second -> y
  Third -> z

createField :: Row -> Row -> Row -> Field
createField x y z = error "not implemented"

setCellInRow :: Row -> Index -> Value -> Row
setCellInRow row i value = error "not implemented"

{-
  Возвращает новое игровое поле, если клетку можно занять.
  Возвращает текстовую ошибку, если место занято.
-}
setCell :: Field -> Index -> Index -> Value -> Either String Field
setCell field i j value = error "not implemented"

{-
  Возвращает одно из 4х значений:
  - InProgress, если игра продолжается
  - Draw,       если игра закончилась ничьёй
  - XsWon,      если игра закончилась победой крестиков
  - OsWon,      если игра закончилась победой ноликов
-}
getGameState :: Field -> GameState
getGameState field = error "not implemented"