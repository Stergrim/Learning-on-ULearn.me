module XsOsDtos where

data Index = First | Second | Third deriving Eq
data Value = Zero | Cross | Empty deriving Eq
type Row = Index -> Value
type Field = Index -> Row

data GameState = InProgress | Draw | XsWon | OsWon deriving (Eq)

instance Show Index where
  show First = "1"
  show Second = "2"
  show Third = "3"

instance Show Value where
  show Zero = "o"
  show Cross = "x"
  show Empty = "."

instance Show GameState where
  show InProgress = "InProgress"
  show Draw = "Draw. No one won."
  show XsWon = "Xs won. Congratulations!"
  show OsWon = "Os won. Congratulations!"
