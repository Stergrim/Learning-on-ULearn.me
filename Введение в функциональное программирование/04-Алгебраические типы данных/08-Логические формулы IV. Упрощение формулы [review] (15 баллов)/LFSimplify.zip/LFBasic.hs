module LFBasic where 

import Data.Either
import Text.Parsec as P

data LogExpr = FConst
             | TConst
             | Var String
             | Not LogExpr
             | And LogExpr LogExpr
             | Or LogExpr LogExpr
  deriving (Eq,Show)

----------------------------------------------------------------
-- Парсер базового формата 

skipSpaces :: P.Parsec String () ()
skipSpaces = P.spaces

checkSpaces :: P.Parsec String () ()
checkSpaces = P.skipMany1 P.space

parseFalse :: P.Parsec String () LogExpr
parseFalse = do
  P.string "false"
  return FConst
       
parseTrue :: P.Parsec String () LogExpr
parseTrue = do
  P.string "true"
  return TConst
    
startSymbol :: P.Parsec String () Char
startSymbol = choice [ P.letter , P.char '_' ]

nextSymbol :: P.Parsec String () Char
nextSymbol = choice [ P.letter , P.char '_' , P.digit ]
    
parseName :: P.Parsec String () String
parseName = do
  ch <- startSymbol
  s <- P.many nextSymbol
  return (ch : s)
    
parseVar :: P.Parsec String () LogExpr
parseVar = do
  res <- parseName
  return (Var res)
  
parseBasic :: P.Parsec String () LogExpr
parseBasic = parseFalse <|> parseTrue <|> parseVar
  
parseNot :: P.Parsec String () LogExpr
parseNot = do
  P.char '^'
  skipSpaces
  res <- parseExpr
  return (Not res)
  
parseAndOr :: P.Parsec String () LogExpr
parseAndOr = do
  P.char '('
  skipSpaces
  expr1 <- parseExpr
  checkSpaces
  op <- P.oneOf "&|"
  checkSpaces
  expr2 <- parseExpr
  skipSpaces
  P.char ')'
  if op == '|'
     then return $ Or expr1 expr2
     else return $ And expr1 expr2

parseExpr :: P.Parsec String () LogExpr
parseExpr = parseBasic <|> parseNot <|> parseAndOr

parseLogExpr :: String -> Either ParseError LogExpr
parseLogExpr str = parse (do
    skipSpaces
    res <- parseExpr
    skipSpaces
    P.eof
    return res
    ) "" str

    
instance Read LogExpr where
  readsPrec _ input = 
    let res = parseLogExpr input 
    in case res of
            Left _ -> [(FConst, input)]
            Right e -> [(e,"")]
                          


