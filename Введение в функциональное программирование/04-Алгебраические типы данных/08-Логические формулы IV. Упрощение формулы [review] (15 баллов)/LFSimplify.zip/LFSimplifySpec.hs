module LFSimplifySpec where

import Test.Hspec
import Test.QuickCheck

import LFBasic
import LFSimplify

toKeep1 = read "^(x & (y | x))"
toKeep2 = read "((x & ^z) | (y | x))"

main = hspec spec

spec :: Spec
spec = do
  describe "Simplify logical formula" $ do
    it "const False" $
      simplify FConst `shouldBe` FConst
    it "const True" $
      simplify TConst `shouldBe` TConst

    it "tautology 1" $
      simplify (read "(abc | ^abc)") `shouldBe` TConst
    it "tautology 2" $
      simplify (read "(^(^A | B) | (^(^B | C) | (^A | C)))") `shouldBe` TConst
      
    it "contradiction 1" $
      simplify (read "(abc & ^abc)") `shouldBe` FConst
    it "contradiction 2" $
      simplify (read "((^A & B) & ((^B | C) & (A | ^C)))") `shouldBe` FConst
      
    it "conjunction with tautology 1" $
      simplify (read "((x | ^x) & y)") `shouldBe` (Var "y")
    it "conjunction with tautology 2" $
      simplify (read "(y & (x | ^x))") `shouldBe` (Var "y")

    it "conjunction with contradiction 1" $
      simplify (read "((x & ^x) & y)") `shouldBe` FConst
    it "conjunction with contradiction 2" $
      simplify (read "(y & (x & ^x))") `shouldBe` FConst
      
    it "disjunction with tautology 1" $
      simplify (read "((x | ^x) | y)") `shouldBe` TConst
    it "disjunction with tautology 2" $
      simplify (read "(y | (x | ^x))") `shouldBe` TConst

    it "disjunction with contradiction 1" $
      simplify (read "((x & ^x) | y)") `shouldBe` (Var "y")
    it "disjunction with contradiction 2" $
      simplify (read "(y | (x & ^x))") `shouldBe` (Var "y")

    it "negation of tautology 1" $
      simplify (read "^(abc | ^abc)") `shouldBe` FConst
    it "negation of tautology 2" $
      simplify (read "^(^(^A | B) | (^(^B | C) | (^A | C)))") `shouldBe` FConst
      
    it "negation of contradiction 1" $
      simplify (read "^(abc & ^abc)") `shouldBe` TConst
    it "negation of contradiction 2" $
      simplify (read "^((^A & B) & ((^B | C) & (A | ^C)))") `shouldBe` TConst
      
    it "formula to keep 1" $
      simplify toKeep1 `shouldBe` toKeep1
    it "formula to keep 2" $
      simplify toKeep2 `shouldBe` toKeep2
      
      
