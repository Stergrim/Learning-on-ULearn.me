module LFSimplify where

import LFBasic

simplify :: LogExpr -> LogExpr
simplify _ = undefined
