module LFCompute where

import LFBasic

-- [(String,Bool)] — список пар (имя переменной, значение)
-- LogExpr         — формула
compute :: [(String,Bool)] -> LogExpr ->  Bool
compute _ _ = undefined