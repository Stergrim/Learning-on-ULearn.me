module LFComputeSpec where

import Test.Hspec
import Test.QuickCheck

import LFBasic
import LFCompute

longFormula :: LogExpr
longFormula = read "(^(^(M | L) & K) | ((^K & ^M) | N))"

main = hspec spec

spec :: Spec
spec = do
  describe "Compute logical value" $ do
    it "const False" $
      compute [] FConst `shouldBe` False
    it "const True" $
      compute [] TConst `shouldBe` True

    it "conjunction of two Truths" $
      compute [("abc",True), ("e",True)] (And (Var "e") (Var "abc")) `shouldBe` True
    it "conjunction of Truth and False 1" $
      compute [("abc",True), ("e",False)] (And (Var "e") (Var "abc")) `shouldBe` False
    it "conjunction of Truth and False 2" $
      compute [("abc",False), ("e",True)] (And (Var "e") (Var "abc")) `shouldBe` False
    
    it "disjunction of two False" $
      compute [("y1",False), ("z_q_2_",False)] (Or (Var "z_q_2_") (Var "y1")) `shouldBe` False
    it "disjunction of Truth and False 1" $
      compute [("y1",True), ("z_q_2_",False)] (Or (Var "z_q_2_") (Var "y1")) `shouldBe` True
    it "disjunction of Truth and False 2" $
      compute [("y1",False), ("z_q_2_",True)] (Or (Var "z_q_2_") (Var "y1")) `shouldBe` True
    
    it "implication True -> True" $
      compute [("z",False), ("y",True), ("x",True)] (Or (Not (And (Var "x") (Var "y"))) (And (Var "x") (Not (Var "z")))) `shouldBe` True
    it "implication True -> False" $
      compute [("z",True), ("y",True), ("x",True)] (Or (Not (And (Var "x") (Var "y"))) (And (Var "x") (Not (Var "z")))) `shouldBe` False
    it "implication False -> True" $
      compute [("z",False), ("y",False), ("x",True)] (Or (Not (And (Var "x") (Var "y"))) (And (Var "x") (Not (Var "z")))) `shouldBe` True
    it "implication False -> False" $
      compute [("z",False), ("y",True), ("x",False)] (Or (Not (And (Var "x") (Var "y"))) (And (Var "x") (Not (Var "z")))) `shouldBe` True
      
    it "some example 1" $
      compute [("K",True), ("M",False), ("L",False), ("N",False)] longFormula `shouldBe` False
    it "some example 2" $
      compute [("K",True), ("M",True), ("L",False), ("N",False)] longFormula `shouldBe` True
      
      
      
