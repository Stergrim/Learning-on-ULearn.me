module LFTautology where

import LFBasic

isTautology :: LogExpr -> Bool
isTautology _ = undefined