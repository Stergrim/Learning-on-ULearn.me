module LFTautologySpec where

import Test.Hspec
import Test.QuickCheck

import LFBasic
import LFTautology

main = hspec spec

spec :: Spec
spec = do
  describe "Check tautologiness" $ do
    it "const False" $
      isTautology FConst `shouldBe` False
    it "const True" $
      isTautology TConst `shouldBe` True
      
    it "tertium non datur" $
      isTautology (read "(abc | ^abc)") `shouldBe` True
      
    it "some example 1" $
      isTautology (read "(^(p & q) | q)") `shouldBe` True
    it "some example 2" $
      isTautology (read "(^(^A | B) | (^(^B | C) | (^A | C)))") `shouldBe` True
    it "some example 3" $
      isTautology (read "((((A & B ) & C) & (A & (B & C))) | (^((A & B ) & C) & ^(A & (B & C))))") `shouldBe` True
      
    it "not a tautology 1" $
      isTautology (read "((((A | B ) & C) & (A & (B & C))) | (^((A & B ) & C) & ^(A & (^B & C))))") `shouldBe` False
    it "not a tautology 2" $
      isTautology (read "(^(^A & B) & (^(^B & C) | (^A | C)))") `shouldBe` False
    it "not a tautology 3" $
      isTautology (read "((^A & B) | ^(^B | ^C))") `shouldBe` False     
