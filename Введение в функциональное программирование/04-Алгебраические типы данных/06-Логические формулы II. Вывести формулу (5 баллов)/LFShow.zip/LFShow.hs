module LFShow where

import LFBasic

-- Нужно для того, чтобы можно было
-- выводить формулу в ghci
instance Show LogExpr where
  show = showExpr

showExpr :: LogExpr -> String
showExpr _ = undefined