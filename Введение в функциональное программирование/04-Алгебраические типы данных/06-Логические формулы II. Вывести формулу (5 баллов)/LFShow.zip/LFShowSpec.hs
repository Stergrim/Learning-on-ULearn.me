module LFComputeSpec where

import Test.Hspec
import Test.QuickCheck

import LFBasic
import LFShow

main = hspec spec

spec :: Spec
spec = 
  describe "Show logical formula" $ do
    it "const False" $
      show FConst `shouldBe` "false"
    it "const True" $
      show TConst `shouldBe` "true"

    it "conjunction of the truth and a variable" $
      show (And TConst (Var "x")) `shouldBe` "(true & x)"
    it "conjunction of a variable and the false" $
      show (And (Var "y1") FConst) `shouldBe` "(y1 & false)"
    it "conjunction of two variables" $
      show (And (Var "a_") (Var "p1_q2_r3")) `shouldBe` "(a_ & p1_q2_r3)"
      
    it "disjunction of the truth and a variable" $
      show (Or TConst (Var "x")) `shouldBe` "(true | x)"
    it "disjunction of a variable and the false" $
      show (Or (Var "y1") FConst) `shouldBe` "(y1 | false)"
    it "disjunction of two variables" $
      show (Or (Var "a_") (Var "p1_q2_r3")) `shouldBe` "(a_ | p1_q2_r3)"
      
    it "negation of the truth" $
      show (Not TConst) `shouldBe` "^true"
    it "negation of the false" $
      show (Not FConst) `shouldBe` "^false"
    it "negation of a variable" $
      show (Not (Var "XyZ")) `shouldBe` "^XyZ"
      
    it "double negation of the truth" $
      show (Not (Not TConst)) `shouldBe` "^^true"
    it "double negation of the false" $
      show (Not (Not FConst)) `shouldBe` "^^false"
    it "double negation of a variable" $
      show (Not (Not (Var "XyZ"))) `shouldBe` "^^XyZ"
      
    it "conjunction of negations of two variables" $
      show (And (Not (Var "a_")) (Not (Var "p1_q2_r3"))) `shouldBe` "(^a_ & ^p1_q2_r3)"
    it "disjunction of negations of two variables" $
      show (Or (Not (Var "a_")) (Not (Var "p1_q2_r3"))) `shouldBe` "(^a_ | ^p1_q2_r3)"
      
    it "negation of conjunction of two variables" $
      show (Not (And (Var "a_") (Var "p1_q2_r3"))) `shouldBe` "^(a_ & p1_q2_r3)"
    it "negation of disjunction of two variables" $
      show (Not (Or (Var "a_") (Var "p1_q2_r3"))) `shouldBe` "^(a_ | p1_q2_r3)"
      
-- some examples
    it "some example 1" $
      show (Or (Not (And (Not (Or (Var "M") (Var "L"))) (Var "K"))) (Or (And (Not (Var "K")) (Not (Var "M"))) (Var "N")))
        `shouldBe` "(^(^(M | L) & K) | ((^K & ^M) | N))"
    it "some example 2" $
      show (Or (Not (And (Not (Not (Var "p"))) (Var "q"))) (Not (Var "r")))
        `shouldBe` "(^(^^p & q) | ^r)"
    it "some example 3" $
      show (And (And (Var "A") (Or (Not (Var "B")) (Not (Var "C")))) (Or (Or (Not (Not (Var "B"))) (Var "A")) (Var "B")))
        `shouldBe` "((A & (^B | ^C)) & ((^^B | A) | B))"
