module LFBasic where 

data LogExpr = FConst
             | TConst
             | Var String
             | Not LogExpr
             | And LogExpr LogExpr
             | Or LogExpr LogExpr

