{-# LANGUAGE DuplicateRecordFields #-}

module TodoList where

newtype TodoList = TodoList FilePath deriving (Eq, Show)

newtype Id = Id String deriving (Eq, Show)

newtype Title = Title String deriving (Eq, Show)

newtype Deadline = Deadline String deriving (Eq, Show)

newtype Content = Content String deriving (Eq, Show)

-- Тип для чтения Todo
data Todo = Todo
  { todoId :: Id
  , title :: Title
  , content :: Content
  , deadline :: Deadline
  , isDone :: Bool
  } deriving (Eq, Show)

-- Тип для редактирования Todo
data TodoEdit = TodoEdit
  { title :: Title
  , content :: Content
  , deadline :: Deadline
  } deriving (Eq, Show)

createTodoList :: FilePath -> IO TodoList
createTodoList rootFolder = error "not implemented"

addTodo :: TodoList -> Title -> Content -> Deadline -> IO Id
addTodo todoList title text deadline = error "not implemented"

readTodo :: TodoList -> Id -> IO Todo
readTodo todoList id = error "not implemented"

showTodo :: TodoList -> Id -> IO ()
showTodo todoList id = error "not implemented"

removeTodo :: TodoList -> Id -> IO ()
removeTodo todoList id = error "not implemented"

editTodo :: TodoList -> Id -> TodoEdit -> IO ()
editTodo todoList id update = error "not implemented"

setTodoAsDone :: TodoList -> Id -> IO ()
setTodoAsDone todoList id = error "not implemented"

-- Todo должны быть упорядочены по возрастанию deadline'а
readAllTodo :: TodoList -> IO [Todo]
readAllTodo todoList = error "not implemented"

readUnfinishedTodo :: TodoList -> IO [Todo]
readUnfinishedTodo todoList = error "not implemented"

showAllTodo :: TodoList -> IO ()
showAllTodo todoList = error "not implemented"

showUnfinishedTodo :: TodoList -> IO ()
showUnfinishedTodo todoList = error "not implemented"
