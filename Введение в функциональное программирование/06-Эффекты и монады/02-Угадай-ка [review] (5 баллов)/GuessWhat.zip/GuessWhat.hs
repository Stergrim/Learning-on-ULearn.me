module GuessWhat where

playGuessGame :: IO ()
playGuessGame = error "not implemented"