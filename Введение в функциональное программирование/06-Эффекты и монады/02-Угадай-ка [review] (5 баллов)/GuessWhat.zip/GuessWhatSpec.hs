module GuessWhatSpec where

import Control.Monad
import Data.List
import GHC.IO.Handle
import System.Process
import Test.Hspec
import Test.QuickCheck

main = hspec spec

bufferSize :: Int
bufferSize = 10 * 1024

minGuessedNumber :: Int
minGuessedNumber = 0

maxGuessedNumber :: Int
maxGuessedNumber = 100

lessMessage :: String
lessMessage = "Too big"

greaterMessage :: String
greaterMessage = "Too small"

finishedMessage :: String
finishedMessage = "Yep, that's the number!"

spec :: Spec
spec = do
  describe "GuessWhat" $ do
    it "Linear search" $ do
      (Just hin, Just hout, Just herr, ph) <-
        createProcess
          (proc "runghc" ["GuessWhatRunner"])
            { std_out = CreatePipe,
              std_in = CreatePipe,
              std_err = CreatePipe
            }
      let check number is_retry =
            if number >= maxGuessedNumber
              then return False
              else do
                when (not is_retry) $ do
                  hPutStr hin (show number ++ "\n")
                  hFlush hin
                message <- hGetLine hout
                if isSubsequenceOf finishedMessage message
                  then return True
                  else
                    if isSubsequenceOf lessMessage message || isSubsequenceOf greaterMessage message
                      then check (number + 1) False
                      else check number True
      found <- check minGuessedNumber False
      found `shouldBe` True
      cleanupProcess (Just hin, Just hout, Just herr, ph)

    it "Binary search" $ do
      (Just hin, Just hout, Just herr, ph) <-
        createProcess
          (proc "runghc" ["GuessWhatRunner"])
            { std_out = CreatePipe,
              std_in = CreatePipe,
              std_err = CreatePipe
            }
      let check left right is_retry = do
            if left > right
              then return False
              else do
                let mid = (left + right) `div` 2
                when (not is_retry) $ do
                  hPutStr hin (show mid ++ "\n")
                  hFlush hin
                message <- hGetLine hout
                if isSubsequenceOf finishedMessage message
                  then return True
                  else
                    if isSubsequenceOf lessMessage message
                      then do
                        check left (mid - 1) False
                      else
                        if isSubsequenceOf greaterMessage message
                          then do
                            check (mid + 1) right False
                          else check left right True
      found <- check minGuessedNumber maxGuessedNumber False
      found `shouldBe` True
      cleanupProcess (Just hin, Just hout, Just herr, ph)
