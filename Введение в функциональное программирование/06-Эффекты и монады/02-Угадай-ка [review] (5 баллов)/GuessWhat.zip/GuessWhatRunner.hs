module GuessWhatRunner where

import GuessWhat

main :: IO ()
main = playGuessGame
