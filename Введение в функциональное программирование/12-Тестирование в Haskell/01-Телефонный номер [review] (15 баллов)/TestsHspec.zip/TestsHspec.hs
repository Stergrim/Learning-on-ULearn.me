{-# LANGUAGE OverloadedStrings #-}

module TestsHspec where

import Test.Hspec
import PhoneNumberNormalization

{-
    Реализация функции `parse` передаётся явно в качестве
    аргумента для автоматической проверки тестов.

    Для запуска тестов:
    *TestsHspec> hspec $ spec parse
-}
spec :: (PhoneNumber -> Either Error PhoneNumber) -> Spec
spec implementation = undefined
