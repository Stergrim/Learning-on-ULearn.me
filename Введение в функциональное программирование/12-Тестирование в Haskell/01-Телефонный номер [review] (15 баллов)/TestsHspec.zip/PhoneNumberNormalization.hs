module PhoneNumberNormalization where

import Data.Text
import Prelude hiding (null, all, length, filter)
import Data.Char (isDigit)

data Error = IsEmptyOrWhitespace | Invalid deriving (Eq, Show)
type PhoneNumber = Text

parse :: Text -> Either Error PhoneNumber
parse phone = do
  validate phone
  toInternalFormat phone
  where
    validate :: Text -> Either Error ()
    validate raw
      | null (strip raw) = Left IsEmptyOrWhitespace
      | not $ all (\c -> isDigit c || isSpecSymbol c) raw = Left Invalid
      | otherwise = Right ()

    isSpecSymbol :: Char -> Bool
    isSpecSymbol c = elem c ['-', '(', ')', '+', ' ']

    toInternalFormat :: Text -> Either Error Text
    toInternalFormat raw = checkLength normalized
      where
        normalized = filter (\c -> not $ isSpecSymbol c) raw
        checkLength s = if length s == 11 then Right s else Left Invalid